package coremain

// Various CoreDNS constants.
const (
	CoreVersion = "1.8.6"
	coreName    = "CoreDNS"
	serverType  = "dns"
)
