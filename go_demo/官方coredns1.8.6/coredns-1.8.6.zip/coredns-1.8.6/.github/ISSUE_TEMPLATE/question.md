---
name: Question
about: A question related to CoreDNS
labels: question

---
<!--
Please only use this template for submitting a generic question.
Or consider using a GitHub discussion https://github.com/coredns/coredns/discussions
-->
