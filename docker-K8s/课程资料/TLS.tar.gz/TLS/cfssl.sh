cp cfssl cfssl-certinfo cfssljson /usr/local/bin/
chmod +x /usr/local/bin/cfssl*
