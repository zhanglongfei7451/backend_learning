from django.apps import AppConfig


class OperationsConfig(AppConfig):
    name = 'operations'
    verbose_name = '操作模块'
