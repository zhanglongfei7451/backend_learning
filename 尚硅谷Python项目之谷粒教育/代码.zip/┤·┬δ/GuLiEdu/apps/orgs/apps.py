from django.apps import AppConfig


class OrgsConfig(AppConfig):
    name = 'orgs'
    verbose_name = '机构模块'
