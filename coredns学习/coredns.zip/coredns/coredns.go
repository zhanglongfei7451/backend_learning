package main

//go:generate go run directives_generate.go
//go:generate go run owners_generate.go

//import两个包文件，执行包文件中的init函数
import (
	_ "github.com/coredns/coredns/core/plugin" // Plug in CoreDNS.
	"github.com/coredns/coredns/coremain"
)

func main() {
	coremain.Run()
}
