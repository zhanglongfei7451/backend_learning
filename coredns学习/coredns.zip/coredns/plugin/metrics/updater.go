package metrics

import (
	"github.com/coredns/coredns/plugin/manage"
)

func (m *Metrics) Update(resourceType string, operateType string, content interface{}) error {
	domain, ok := content.(*manage.Domain)
	if !ok {
		return nil
	}
	log.Debugf("resourceType: %v,operateType: %v,content: %v", resourceType, operateType, content)

	switch operateType {
	case manage.ADD:
		return m.addDomain(domain.DomainName)
	case manage.DELETE:
		return m.delDomain(domain.DomainName)
	default:
		return nil
	}
}

// get domain from db and add to zoneNames variable
func (m *Metrics) addDomain(name string) error {
	m.AddZone(name)
	return nil
}

// del from zoneNames variable
func (m *Metrics) delDomain(name string) error {
	m.RemoveZone(name)
	return nil
}
