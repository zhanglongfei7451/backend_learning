package metrics

import (
	"fmt"
	"github.com/coredns/coredns/plugin/manage"
	"testing"
)

func Test_metrics_Update(t *testing.T) {
	met := New(defaultAddr)

	type args struct {
		resourceType string
		operateType  string
		content      manage.Domain
	}

	testAddDomain := []struct {
		args    args
		wantErr bool
	}{
		{
			args{
				"DOMAIN", "ADD", manage.Domain{DomainName: "a.com"},
			},
			false,
		},
	}

	for _, tt := range testAddDomain {
		t.Run("testAddDomain", func(t *testing.T) {
			if err := met.Update(tt.args.resourceType, tt.args.operateType, &tt.args.content); (err != nil) != tt.wantErr {
				t.Errorf("Update() error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
	fmt.Println(met.zones)

	if met.zones.Size() != 1 {
		t.Errorf("the number of domain name is not expected, expected = %d, real = %d", 1, met.zones.Size())
	}

	testDelDomain := []struct {
		args    args
		wantErr bool
	}{
		{
			args{
				"DOMAIN", "DELETE", manage.Domain{DomainName: "a.com"},
			},
			false,
		},
	}
	for _, tt := range testDelDomain {
		t.Run("testDelDomain", func(t *testing.T) {
			if err := met.Update(tt.args.resourceType, tt.args.operateType, &tt.args.content); (err != nil) != tt.wantErr {
				t.Errorf("Update() error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
	fmt.Println(met.zones)
	if met.zones.Size() != 0 {
		t.Errorf("the number of domain name is not expected, expected = %d, real = %d", 0, met.zones.Size())
	}
}
