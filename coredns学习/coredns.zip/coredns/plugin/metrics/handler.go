package metrics

import (
	"context"
	"github.com/coredns/coredns/plugin"
	"github.com/coredns/coredns/plugin/metrics/vars"
	"github.com/coredns/coredns/plugin/pkg/dnstest"
	"github.com/coredns/coredns/plugin/pkg/rcode"
	"github.com/coredns/coredns/request"

	"github.com/miekg/dns"
	"strings"
)

// default zone for qname's zone not in db
const defaultZone = "."

// ServeDNS implements the Handler interface.
func (m *Metrics) ServeDNS(ctx context.Context, w dns.ResponseWriter, r *dns.Msg) (int, error) {
	state := request.Request{W: w, Req: r}

	qname := state.Name()
	zone := m.FindBestZone(qname)

	// Record response to get status code and size of the reply.
	rw := dnstest.NewRecorder(w)
	status, err := plugin.NextOrFailure(m.Name(), m.Next, ctx, rw, r)

	rc := rw.Rcode
	if !plugin.ClientWrite(status) {
		// when no response was written, fallback to status returned from next plugin as this status
		// is actually used as rcode of DNS response
		// see https://github.com/coredns/coredns/blob/master/core/dnsserver/server.go#L318
		rc = status
	}
	vars.Report(WithServer(ctx), state, zone, rcode.ToString(rc), rw.Len, rw.Start)

	return status, err
}

// Name implements the Handler interface.
func (m *Metrics) Name() string { return "prometheus" }

// FindBestZone can save time 10%-40%
func (m *Metrics) FindBestZone(qname string) string {
	if len(qname) <= 1 || m.zones.Size() == 0 {
		return defaultZone
	}
	if m.zones.Has(qname) {
		return qname
	}
	for {
		index := strings.IndexByte(qname, '.')
		if index < 0 {
			return defaultZone
		}
		qname = qname[index+1:]
		if len(qname) <= 0 {
			return defaultZone
		}
		if m.zones.Has(qname) {
			return qname
		}
	}
}
