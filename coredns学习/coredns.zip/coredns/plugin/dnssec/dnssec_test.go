package dnssec

import (
	"github.com/coredns/coredns/plugin/manage"
	"testing"
	"time"

	"github.com/coredns/coredns/plugin/pkg/cache"
	"github.com/coredns/coredns/plugin/test"
	"github.com/coredns/coredns/request"

	"github.com/miekg/dns"
)

var db = &manage.DnssecKey{
	DomainName:   "miek.nl.",
	ZskFlags:     256,
	Protocol:     3,
	KeyAlgorithm: 13,
	ZskKey:       "xsAR1s2EnxB09rpB1Z9tjUEhPSstA7AFGHQtb8A7jmGecNCAg2AF3F36TCExo05d/DcyX/vd9lmwWsPuBrK3jg==",
	ZskPrivate:   "eyaVfuYmn7fTeoNvn/uKTpN1Wk+KHVwCgrFblrvUeW8=",
	KskFlags:     257,
	KskKey:       "j3BPfMNI/IxJg6zteGafWlshRTZj4D8CBPHxXRhZhQnGgZZUdudQOLgRNubBkcWtAsDxbF6iV/VZacymoI0NUA==",
	KskPrivate:   "eyaVfuYmn7fTeoNvn/uKTpN1Wk+KHVwCgrFblrvUeW8=",
}

func TestZoneSigning(t *testing.T) {
	d := newDnssec()
	defer d.delDnssecKey(db)

	m := testMsg()
	state := request.Request{Req: m, Zone: "miek.nl."}

	m = d.Sign(state, time.Now().UTC(), server)
	if !section(m.Answer, 1) {
		t.Errorf("Answer section should have 1 RRSIG")
	}
	if !section(m.Ns, 1) {
		t.Errorf("Authority section should have 1 RRSIG")
	}
}

func TestSigningCname(t *testing.T) {
	d := newDnssec()
	defer d.delDnssecKey(db)

	m := testMsgCname()
	state := request.Request{Req: m, Zone: "miek.nl."}
	m = d.Sign(state, time.Now().UTC(), server)
	if !section(m.Answer, 1) {
		t.Errorf("Answer section should have 1 RRSIG")
	}
}

func TestSigningDname(t *testing.T) {
	d := newDnssec()
	defer d.delDnssecKey(db)

	m := testMsgDname()
	state := request.Request{Req: m, Zone: "miek.nl."}
	// We sign *everything* we see, also the synthesized CNAME.
	m = d.Sign(state, time.Now().UTC(), server)
	if !section(m.Answer, 3) {
		t.Errorf("Answer section should have 3 RRSIGs")
	}
}

func TestSigningEmpty(t *testing.T) {
	d := newDnssec()
	defer d.delDnssecKey(db)

	m := testEmptyMsg()
	m.SetQuestion("a.miek.nl.", dns.TypeA)
	state := request.Request{Req: m, Zone: "miek.nl."}
	m = d.Sign(state, time.Now().UTC(), server)
	if !section(m.Ns, 2) {
		t.Errorf("Authority section should have 2 RRSIGs")
	}
}

func section(rss []dns.RR, nrSigs int) bool {
	i := 0
	for _, r := range rss {
		if r.Header().Rrtype == dns.TypeRRSIG {
			i++
		}
	}
	return nrSigs == i
}

func testMsg() *dns.Msg {
	// don't care about the message header
	return &dns.Msg{
		Answer: []dns.RR{test.MX("miek.nl.	1703	IN	MX	1 aspmx.l.google.com.")},
		Ns: []dns.RR{test.NS("miek.nl.	1703	IN	NS	omval.tednet.nl.")},
	}
}

func testMsgCname() *dns.Msg {
	return &dns.Msg{
		Answer: []dns.RR{test.CNAME("www.miek.nl.	1800	IN	CNAME	a.miek.nl.")},
	}
}

func testMsgDname() *dns.Msg {
	return &dns.Msg{
		Answer: []dns.RR{
			test.CNAME("a.dname.miek.nl.	1800	IN	CNAME	a.test.miek.nl."),
			test.A("a.test.miek.nl.	1800	IN	A	139.162.196.78"),
			test.DNAME("dname.miek.nl.	1800	IN	DNAME	test.miek.nl."),
		},
	}
}

func testEmptyMsg() *dns.Msg {
	// don't care about the message header
	return &dns.Msg{
		Ns: []dns.RR{test.SOA("miek.nl.	1800	IN	SOA	ns.miek.nl. dnsmaster.miek.nl. 2017100301 200 100 604800 3600")},
	}
}

func newDnssec() Dnssec {
	d := New(map[string][]*DNSKEY{}, nil, cache.New(defaultCap))
	d.addDnssecKey(db)
	return d
}
