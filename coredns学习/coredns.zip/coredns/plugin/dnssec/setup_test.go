package dnssec

import (
	"strings"
	"testing"

	"github.com/coredns/caddy"
)

func TestSetupDnssec(t *testing.T) {
	tests := []struct {
		input              string
		shouldErr          bool
		expectedCapacity   int
		expectedErrContent string
	}{
		{`dnssec`, false, defaultCap, ""},
		{
			`dnssec {
				cache_capacity 100
			}`, false, 100, "",
		},
		// fails
		{`dnssec
		  dnssec`, true, defaultCap, ""},
	}

	for i, test := range tests {
		c := caddy.NewTestController("dns", test.input)
		capacity, err := capacityParamParse(c)

		if test.shouldErr && err == nil {
			t.Errorf("Test %d: Expected error but found %s for input %s", i, err, test.input)
		}

		if err != nil {
			if !test.shouldErr {
				t.Errorf("Test %d: Expected no error but found one for input %s. Error was: %v", i, test.input, err)
			}

			if !strings.Contains(err.Error(), test.expectedErrContent) {
				t.Errorf("Test %d: Expected error to contain: %v, found error: %v, input: %s", i, test.expectedErrContent, err, test.input)
			}
		}
		if !test.shouldErr {
			if capacity != test.expectedCapacity {
				t.Errorf("Dnssec not correctly set capacity for input '%s' Expected: '%d', actual: '%d'", test.input, capacity, test.expectedCapacity)
			}
		}
	}
}
