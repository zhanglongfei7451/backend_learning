package dnssec

import (
	"crypto"
	"crypto/ecdsa"
	"crypto/ed25519"
	"crypto/elliptic"
	"crypto/rsa"
	"encoding/base64"
	"github.com/coredns/coredns/plugin/manage"
	"github.com/miekg/dns"
	"math/big"
)

// PRIVATE_KEY 为了适应miekg/dns内部方法readPrivateKeyECDSA
const PRIVATE_KEY = "privatekey"

//Update 从manage获取数据
func (d *Dnssec) Update(resourceType string, operateType string, content interface{}) error {
	var err error
	// 当域名被删除后，dnssec应该默认被关闭，但一定要提醒用户刪除ds记录
	if manage.DOMAIN == resourceType && manage.DELETE == operateType {
		dm := content.(*manage.Domain)
		log.Infof("resourceType: %v,operateType: %v,content: %v", resourceType, operateType, dm.DomainName)
		c := &manage.DnssecKey{
			DomainName: dm.DomainName,
		}
		d.delDnssecKey(c)
	}

	// 若是DNSSEC则进行操作
	if manage.DNSSEC != resourceType {
		return nil
	}

	switch operateType {
	case manage.ADD:
		c := content.(*manage.DnssecKey)
		log.Infof("resourceType: %v,operateType: %v,content: %v", resourceType, operateType, c.DomainName)
		err = d.addDnssecKey(c)
	case manage.DELETE:
		c := content.(*manage.DnssecKey)
		log.Infof("resourceType: %v,operateType: %v,content: %v", resourceType, operateType, c.DomainName)
		d.delDnssecKey(c)
	default:
		return nil
	}
	return err
}

//addDnssecKey 新增
func (d *Dnssec) addDnssecKey(db *manage.DnssecKey) error {
	zsk_k, err := parseKeyFileFrDB(db.DomainName, db.ZskFlags, db.Protocol, db.KeyAlgorithm, db.ZskKey, db.ZskPrivate)
	if err != nil {
		log.Infof("从dnssec_key中读取ZSK密钥失败，domain=%v,error=%v", db.DomainName, err)
		return err
	}
	ksk_k, err := parseKeyFileFrDB(db.DomainName, db.KskFlags, db.Protocol, db.KeyAlgorithm, db.KskKey, db.KskPrivate)
	if err != nil {
		log.Infof("从dnssec_key中读取KSK密钥失败，domain=%v,error=%v", db.DomainName, err)
		return err
	}

	d.zones[db.DomainName] = []*DNSKEY{zsk_k, ksk_k}

	return nil
}

//delDnssecKey 刪除
func (d *Dnssec) delDnssecKey(db *manage.DnssecKey) {
	delete(d.zones, db.DomainName)
}

//parseKeyFileFrDB 从数据库中解析得到公钥和私钥
//zsk_k, err := parseKey(d.DomainName, d.ZskFlags, d.Protocol, d.KeyAlgorithm, d.ZskKey, d.ZskPrivate)
//ksk_k, err := parseKey(d.DomainName, d.KskFlags, d.Protocol, d.KeyAlgorithm, d.KskKey, d.KskPrivate)
func parseKeyFileFrDB(domain string, flags uint16, protocol uint8, algo uint8, pubK string, privK string) (*DNSKEY, error) {
	key := &dns.DNSKEY{
		Hdr:       dns.RR_Header{Name: domain, Rrtype: dns.TypeDNSKEY, Class: dns.ClassINET, Ttl: 3600},
		Flags:     flags,
		Protocol:  protocol,
		Algorithm: algo,
		PublicKey: pubK,
	}

	p, e := readPrivateKeyFrDB(key, privK, algo)
	if e != nil {
		return nil, e
	}
	return formatPrivateKey(p, key)

}

//formatPrivateKey 格式化
func formatPrivateKey(p crypto.PrivateKey, key *dns.DNSKEY) (*DNSKEY, error) {
	if s, ok := p.(*ecdsa.PrivateKey); ok {
		// 目前的算法ECDSAP256SHA256对应路径
		return &DNSKEY{K: key, s: s, tag: key.KeyTag()}, nil
	}
	if s, ok := p.(*rsa.PrivateKey); ok {
		return &DNSKEY{K: key, s: s, tag: key.KeyTag()}, nil
	}
	if s, ok := p.(ed25519.PrivateKey); ok {
		return &DNSKEY{K: key, s: s, tag: key.KeyTag()}, nil
	}

	return &DNSKEY{K: key, s: nil, tag: key.KeyTag()}, nil
}

// readPrivateKeyFrDB 解析得到私钥
func readPrivateKeyFrDB(k *dns.DNSKEY, privatekey string, algorithm uint8) (crypto.PrivateKey, error) {
	m := make(map[string]string)
	m[PRIVATE_KEY] = privatekey // 为了适应miekg/dns内部方法

	switch algorithm {
	case dns.ECDSAP256SHA256, dns.ECDSAP384SHA384:
		//目前是这个ECDSAP256SHA256算法
		priv, err := readPrivateKeyECDSA(m)
		if err != nil {
			return nil, err
		}
		pub := publicKeyECDSA(k)
		if pub == nil {
			return nil, dns.ErrKey
		}
		priv.PublicKey = *pub
		return priv, nil
	default:
		return nil, dns.ErrAlg
	}
}

//readPrivateKeyECDSA from miekg/dns
func readPrivateKeyECDSA(m map[string]string) (*ecdsa.PrivateKey, error) {
	p := new(ecdsa.PrivateKey)
	p.D = new(big.Int)
	// TODO: validate that the required flags are present
	for k, v := range m {
		switch k {
		case PRIVATE_KEY:
			v1, err := fromBase64([]byte(v))
			if err != nil {
				return nil, err
			}
			p.D.SetBytes(v1)
		case "created", "publish", "activate":
			/* not used in Go (yet) */
		}
	}
	return p, nil
}

//fromBase64 from miekg/dns
func fromBase64(s []byte) (buf []byte, err error) {
	buflen := base64.StdEncoding.DecodedLen(len(s))
	buf = make([]byte, buflen)
	n, err := base64.StdEncoding.Decode(buf, s)
	buf = buf[:n]
	return
}

//publicKeyECDSA from miekg/dns
func publicKeyECDSA(k *dns.DNSKEY) *ecdsa.PublicKey {
	keybuf, err := fromBase64([]byte(k.PublicKey))
	if err != nil {
		return nil
	}
	pubkey := new(ecdsa.PublicKey)
	switch k.Algorithm {
	case dns.ECDSAP256SHA256:
		pubkey.Curve = elliptic.P256()
		if len(keybuf) != 64 {
			// wrongly encoded key
			return nil
		}
	case dns.ECDSAP384SHA384:
		pubkey.Curve = elliptic.P384()
		if len(keybuf) != 96 {
			// Wrongly encoded key
			return nil
		}
	}
	pubkey.X = new(big.Int).SetBytes(keybuf[:len(keybuf)/2])
	pubkey.Y = new(big.Int).SetBytes(keybuf[len(keybuf)/2:])
	return pubkey
}
