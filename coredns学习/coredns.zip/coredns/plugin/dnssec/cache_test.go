package dnssec

import (
	"github.com/coredns/coredns/request"
	"testing"
	"time"
)

func TestCacheSet(t *testing.T) {
	m := testMsg()
	state := request.Request{Req: m, Zone: "miek.nl."}
	k := hash(m.Answer) // calculate *before* we add the sig
	d := newDnssec()
	defer d.delDnssecKey(db)
	d.Sign(state, time.Now().UTC(), server)

	_, ok := d.get(k, server)
	if !ok {
		t.Errorf("Signature was not added to the cache")
	}
}

func TestCacheNotValidExpired(t *testing.T) {
	m := testMsg()
	state := request.Request{Req: m, Zone: "miek.nl."}
	k := hash(m.Answer) // calculate *before* we add the sig
	d := newDnssec()
	defer d.delDnssecKey(db)
	d.Sign(state, time.Now().UTC().AddDate(0, 0, -9), server)

	_, ok := d.get(k, server)
	if ok {
		t.Errorf("Signature was added to the cache even though not valid")
	}
}

func TestCacheNotValidYet(t *testing.T) {
	m := testMsg()
	state := request.Request{Req: m, Zone: "miek.nl."}
	k := hash(m.Answer) // calculate *before* we add the sig
	d := newDnssec()
	defer d.delDnssecKey(db)
	d.Sign(state, time.Now().UTC().AddDate(0, 0, +9), server)

	_, ok := d.get(k, server)
	if ok {
		t.Errorf("Signature was added to the cache even though not valid yet")
	}
}
