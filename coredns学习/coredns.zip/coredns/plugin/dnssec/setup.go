package dnssec

import (
	"github.com/coredns/caddy"
	"github.com/coredns/coredns/core/dnsserver"
	"github.com/coredns/coredns/plugin"
	"github.com/coredns/coredns/plugin/pkg/cache"
	clog "github.com/coredns/coredns/plugin/pkg/log"
	"strconv"
)

var log = clog.NewWithPlugin("dnssec")

func init() { plugin.Register("dnssec", setup) }

func setup(c *caddy.Controller) error {
	zones := make(map[string][]*DNSKEY)

	capacity, err := capacityParamParse(c)
	if err != nil {
		return plugin.Error("dnssec", err)
	}

	ca := cache.New(capacity)
	stop := make(chan struct{})

	c.OnShutdown(func() error {
		close(stop)
		return nil
	})
	c.OnStartup(func() error {
		go periodicClean(ca, stop)
		return nil
	})

	dnsserver.GetConfig(c).AddPlugin(func(next plugin.Handler) plugin.Handler {
		d := New(zones, next, ca)
		return &d
	})

	return nil
}

// 解析cache的容量参数
func capacityParamParse(c *caddy.Controller) (int, error) {
	capacity := defaultCap

	i := 0
	for c.Next() {
		if i > 0 {
			return 0, plugin.ErrOnce
		}
		i++
		for c.NextBlock() {

			switch x := c.Val(); x {
			case "cache_capacity":
				if !c.NextArg() {
					return 0, c.ArgErr()
				}
				value := c.Val()
				cacheCap, err := strconv.Atoi(value)
				if err != nil {
					return 0, err
				}
				capacity = cacheCap
			default:
				return 0, c.Errf("unknown property '%s'", x)
			}

		}
	}

	return capacity, nil
}
