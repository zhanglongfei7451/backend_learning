package iresolver

import (
	"fmt"
	"github.com/coredns/coredns/plugin/iresolver/tree"
	"github.com/coredns/coredns/plugin/manage"
	"github.com/miekg/dns"
	"k8s.io/utils/strings/slices"
	"net"
	"strconv"
	"strings"
)

func (r *IResolver) Update(resourceType string, operateType string, content interface{}) error {
	var err error
	switch resourceType {
	case manage.DOMAIN:
		log.Infof("resourceType: %v,operateType: %v,content: %v", resourceType, operateType, content)
		err = r.dealDomain(operateType, content.(*manage.Domain))
	case manage.RECORD:
		log.Infof("resourceType: %v,operateType: %v,content: %v", resourceType, operateType, content)
		err = r.dealRecord(operateType, content.(*manage.Record))
	default:
		return nil
	}
	return err
}

func (r *IResolver) dealDomain(operateType string, domain *manage.Domain) error {
	szone := r.Zones[domain.DomainName]
	switch operateType {
	case manage.ADD:
		// 幂等处理
		if szone != nil {
			return fmt.Errorf("Repeatedly add %v", domain)
		}
		zone := NewZone(domain.DomainName)
		zone.SOA = &domain.Soa
		zone.Enabled = domain.Enabled
		r.Zones[domain.DomainName] = zone
	case manage.DELETE:
		if szone == nil {
			return fmt.Errorf("not found %v to delete", domain)
		}
		delete(r.Zones, domain.DomainName)
	case manage.UPDATE: // TODO 仅能更新SOA信息
		if szone == nil {
			return fmt.Errorf("not found %v to update", domain)
		}
		szone.Lock()
		r.Zones[domain.DomainName].SOA = &domain.Soa
		szone.Unlock()
	case manage.ENABLE:
		if szone == nil {
			return fmt.Errorf("not found %v to enable", domain)
		}
		szone.Lock()
		r.Zones[domain.DomainName].Enabled = true
		szone.Unlock()
	case manage.DISABLE:
		if szone == nil {
			return fmt.Errorf("not found %v to disable", domain)
		}
		szone.Lock()
		r.Zones[domain.DomainName].Enabled = false
		szone.Unlock()
	case manage.PACKAGE_UPDATE:
		if szone == nil {
			return fmt.Errorf("not found %v to update", domain)
		}
		szone.Lock()
		r.Zones[domain.DomainName].SOA = &domain.Soa
		szone.Unlock()
	default:
		return fmt.Errorf("unsupported domain operate type %s", operateType)
	}
	return nil
}

func (r *IResolver) dealRecord(operateType string, record *manage.Record) error {
	zone := r.Zones[record.DomainName]
	if zone == nil {
		return fmt.Errorf("not found the zone of %v domainName", record.DomainName)
	}
	var crr tree.CRR
	recode2crrPre(record, &crr)
	zone.Lock()
	defer zone.Unlock()
	switch record.RType {
	case dns.TypeA:
		a := dns.A{
			Hdr: createRRHeaderByRecode(record),
			A:   net.ParseIP(record.Value),
		}
		crr.RR = &a
	case dns.TypeAAAA:
		aaaa := dns.AAAA{
			Hdr:  createRRHeaderByRecode(record),
			AAAA: net.ParseIP(record.Value),
		}
		crr.RR = &aaaa
	case dns.TypeCNAME:
		cname := dns.CNAME{
			Hdr:    createRRHeaderByRecode(record),
			Target: record.Value,
		}
		crr.RR = &cname

	case dns.TypeNS:
		nsrr := dns.NS{
			Hdr: createRRHeaderByRecode(record),
			Ns:  record.Value,
		}
		if record.RName == "@" {
			switch operateType {
			case manage.ADD:
				zone.NS = append(zone.NS, &nsrr)
			case manage.DELETE:
				zone.NS = nil
			}
			return nil
		}
		crr.RR = &nsrr
	case dns.TypeMX:
		mx := dns.MX{
			Hdr:        createRRHeaderByRecode(record),
			Preference: uint16(record.MxPri),
			Mx:         record.Value,
		}
		crr.RR = &mx
	case dns.TypeTXT:
		txt := dns.TXT{
			Hdr: createRRHeaderByRecode(record),
			Txt: []string{record.Value},
		}
		crr.RR = &txt
	case dns.TypeSRV:
		srvValueList := strings.Split(record.Value, " ")
		priority, err := strconv.Atoi(srvValueList[0])
		if err != nil {
			return fmt.Errorf(" %v cannt convert int", srvValueList[0])
		}
		weight, err := strconv.Atoi(srvValueList[1])
		if err != nil {
			return fmt.Errorf(" %v cannt convert int", srvValueList[1])
		}
		port, err := strconv.Atoi(srvValueList[2])
		if err != nil {
			return fmt.Errorf(" %v cannt convert int", srvValueList[2])
		}

		srv := dns.SRV{
			Hdr:      createRRHeaderByRecode(record),
			Priority: uint16(priority),
			Weight:   uint16(weight),
			Port:     uint16(port),
			Target:   dns.Fqdn(srvValueList[3]),
		}
		crr.RR = &srv
	case dns.TypePTR:
		ptr := dns.PTR{
			Hdr: createRRHeaderByRecode(record),
			Ptr: record.Value,
		}
		crr.RR = &ptr
	case dns.TypeSPF:
		spf := dns.SPF{
			Hdr: createRRHeaderByRecode(record),
			Txt: []string{record.Value},
		}
		crr.RR = &spf
	case dns.TypeCAA:
		caaValueList := strings.Split(record.Value, " ")
		flag, err := strconv.Atoi(caaValueList[0])
		if err != nil {
			return fmt.Errorf(" %v can not convert int", caaValueList[0])
		}
		val := strings.Replace(caaValueList[2], "\"", "", 2)
		caa := dns.CAA{
			Hdr:   createRRHeaderByRecode(record),
			Flag:  uint8(flag),
			Tag:   caaValueList[1],
			Value: val,
		}
		crr.RR = &caa
	case dns.TypeNone:
		txt := dns.TXT{
			Hdr: createRRHeaderByRecode(record),
			Txt: []string{"only for delete old rr"},
		}
		crr.RR = &txt
	// case dns.TypeRP: // 云解析暂时没有，manager侧数据结构未协商好
	//	rp := dns.RP{
	//		Hdr:  createRRHeaderByRecode(record),
	//		Mbox: "",
	//		Txt:  "",
	//	}
	default:
		return fmt.Errorf("unsupported record type %v", record.RType)
	}
	return operate(operateType, zone, crr)
}

func operate(operateType string, zone *Zone, crr tree.CRR) error {
	selem, found := zone.Search(crr.Header().Name)
	switch operateType {
	case manage.ADD, manage.ENABLE:
		// 增加幂等处理
		if found {
			scrr := selem.TypeCRRByRRId(crr.Header().Rrtype, crr.RRId)
			if scrr != nil && scrr.RRId == crr.RRId {
				return fmt.Errorf("Repeatedly add %v ", crr)
			}
		}
		if crr.Enabled {
			zone.Tree.Insert(crr)
		}
	case manage.DELETE, manage.DISABLE:
		if !found {
			return fmt.Errorf("not found %v to delete", crr)
		}
		selem.DeleteByRRId(crr)
		if selem.Empty() {
			zone.Tree.DeleteNode(crr)
		}
	}
	return nil
}

func recode2crrPre(record *manage.Record, crr *tree.CRR) {
	crr.RRId = record.RecordId
	crr.LineId = record.LineId
	crr.Weight = record.Weight
	crr.Enabled = record.Enabled
}

func createRRHeaderByRecode(record *manage.Record) dns.RR_Header {
	return dns.RR_Header{
		Name:   preRRHeaderName(record),
		Rrtype: record.RType,
		Class:  dns.ClassINET,
		Ttl:    record.Ttl,
	}
}

func preRRHeaderName(record *manage.Record) string {
	switch record.RName {
	case "@":
		return record.DomainName
	default:
		return record.RName + "." + record.DomainName
	}
}

func sliceDelStrElem(s []string, v string) []string {
	idx := slices.Index(s, v)
	s = append(s[:idx], s[idx+1:]...)
	return s
}

// RemoveString returns a newly created []string that contains all items from slice that
// are not equal to s and modifier(s) in case modifier func is provided.
func RemoveString(slice []string, s string, modifier func(s string) string) []string {
	newSlice := make([]string, 0)
	for _, item := range slice {
		if item == s {
			continue
		}
		if modifier != nil && modifier(item) == s {
			continue
		}
		newSlice = append(newSlice, item)
	}
	if len(newSlice) == 0 {
		// Sanitize for unit tests so we don't need to distinguish empty array
		// and nil.
		newSlice = nil
	}
	return newSlice
}
