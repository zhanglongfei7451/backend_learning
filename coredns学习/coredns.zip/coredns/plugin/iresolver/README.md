# iresolver

## Name

*iresolver* - intelligence resolver. 智能解析器

## Description

The *iresolver* plugin is used for resolver domain with line and record weight . this plugin implements "manage" plugin
`Updater` interface, so the "manage" plugin can configure domain and record through updater interface. 

## Syntax

~~~
iresover  //with no parameter
~~~
不支持 transfer from/to

## Examples

only support intelligence resolver
~~~ corefile
. {
    iresolver
}
~~~
