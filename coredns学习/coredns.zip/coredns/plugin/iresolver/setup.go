package iresolver

import (
	"github.com/coredns/caddy"
	"github.com/coredns/coredns/core/dnsserver"
	"github.com/coredns/coredns/plugin"
)

func init() { plugin.Register("iresolver", setup) }

func setup(c *caddy.Controller) error {
	zones := make(map[string]*Zone)
	f := IResolver{Zones: zones}
	dnsserver.GetConfig(c).AddPlugin(func(next plugin.Handler) plugin.Handler {
		f.Next = next
		return &f
	})
	return nil
}
