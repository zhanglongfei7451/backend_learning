package tree

import (
	"github.com/miekg/dns"
	"math/rand"
	"time"
)

type CRR struct {
	RRId    string
	LineId  string
	Weight  int16 // -1 表示没有配置权重负载均衡策略
	Enabled bool  // 启用、停用
	dns.RR
}

// Elem is an element in the tree.
type Elem struct {
	m    map[uint16][]CRR
	name string // owner name
}

// newElem returns a new elem.
func newElem(crr CRR) *Elem {
	e := Elem{m: make(map[uint16][]CRR)}
	e.m[crr.RR.Header().Rrtype] = []CRR{crr}
	e.name = crr.Header().Name
	return &e
}

// Types returns the types of the records in e. The returned list is not sorted.
func (e *Elem) Types() []uint16 {
	t := make([]uint16, len(e.m))
	i := 0
	for ty := range e.m {
		t[i] = ty
		i++
	}
	return t
}

// Type returns the RRs with type qtype from e.
func (e *Elem) Type(qtype uint16) []dns.RR {
	rr := []dns.RR(nil)
	for _, crr := range e.m[qtype] {
		rr = append(rr, crr.RR)
	}
	if len(rr) == 0 {
		return nil
	}
	return rr
}

func (e *Elem) TypeCRR(lineIds []string, qtype uint16) []dns.RR {
	var rrs []dns.RR = nil
	var crrs []CRR = nil
	m := e.m[qtype]
	for _, lineID := range lineIds {
		for _, crr := range m {
			if crr.Enabled && lineID == crr.LineId {
				rrs = append(rrs, crr.RR)
				crrs = append(crrs, crr)
			}
		}
		if len(rrs) == 1 {
			return rrs
		}
		if len(rrs) > 1 {
			// 判断是否需要做负载均衡
			wrrEnabled := false
			for _, crr := range crrs { // 判断是否需要进行LB
				if crr.Weight != 0 { // 有一个不等于0 就认为是开启了负载均衡，业务决定的
					wrrEnabled = true
					break
				}
			}
			if wrrEnabled {
				res := wrr(crrs)
				return []dns.RR{rrs[res]}
			}
			return rrs
		}
	}
	return rrs
}

func (e *Elem) TypeCRRByRRId(qtype uint16, rrId string) *CRR {
	for index, crr := range e.m[qtype] {
		if crr.RRId == rrId {
			return &e.m[qtype][index]
		}
	}
	return nil
}

// TypeForWildcard returns the RRs with type qtype from e. The ownername returned is set to qname.
func (e *Elem) TypeForWildcard(qtype uint16, qname string) []dns.RR {
	rrs := e.m[qtype]

	if rrs == nil {
		return nil
	}

	copied := make([]dns.RR, len(rrs))
	for i := range rrs {
		copied[i] = dns.Copy(rrs[i])
		copied[i].Header().Name = qname
	}
	return copied
}

func (e *Elem) TypeForWildcardCRR(lineIds []string, qtype uint16, qname string) []dns.RR {
	var rrs []dns.RR = nil
	var crrs []CRR = nil
	m := e.m[qtype]
	for _, lineID := range lineIds {
		for _, crr := range m {
			if crr.Enabled && lineID == crr.LineId {
				rrs = append(rrs, crr.RR)
				crrs = append(crrs, crr)
			}
		}
		if len(rrs) == 1 {
			break
		}
		if len(rrs) > 1 {
			wrrEnabled := false
			for _, crr := range crrs {
				if crr.Weight != 0 {
					wrrEnabled = true
					break
				}
			}
			if wrrEnabled {
				res := wrr(crrs)
				rrs = []dns.RR{rrs[res]}
			}
		}
	}

	if rrs == nil {
		return nil
	}

	copied := make([]dns.RR, len(rrs))
	for i := range rrs {
		copied[i] = dns.Copy(rrs[i])
		copied[i].Header().Name = qname
	}
	return copied
}

// All returns all RRs from e, regardless of type.
func (e *Elem) All() []dns.RR {
	list := []dns.RR{}
	for _, rrs := range e.m {
		for _, rr := range rrs {
			list = append(list, rr.RR)
		}
	}
	return list
}

// Name returns the name for this node.
func (e *Elem) Name() string {
	if e.name != "" {
		return e.name
	}
	for _, rrs := range e.m {
		e.name = rrs[0].Header().Name
		return e.name
	}
	return ""
}

// Empty returns true is e does not contain any RRs, i.e. is an empty-non-terminal.
func (e *Elem) Empty() bool { return len(e.m) == 0 }

// Insert inserts rr into e. If rr is equal to existing RRs, the RR will be added anyway.
func (e *Elem) Insert(crr CRR) {
	t := crr.RR.Header().Rrtype
	if e.m == nil {
		e.m = make(map[uint16][]CRR)
		e.m[t] = []CRR{crr}
		return
	}
	rrs, ok := e.m[t]
	if !ok {
		e.m[t] = []CRR{crr}
		return
	}

	rrs = append(rrs, crr)
	e.m[t] = rrs
}

// Delete removes all RRs of type rr.Header().Rrtype from e.
func (e *Elem) Delete(rr dns.RR) {
	if e.m == nil {
		return
	}

	t := rr.Header().Rrtype
	delete(e.m, t) // 按type为粒度操作的
}

func (e *Elem) DeleteByRRId(delCrr CRR) {
	if e.m == nil {
		return
	}

	// 如果是更新导致的delete，rrtype是空需要遍历整个map
	if delCrr.Header().Rrtype == dns.TypeNone {
		for rrtype, crrs := range e.m {
			if e.deleteCrr(delCrr, crrs, rrtype) {
				return
			}
		}
	} else {
		// 如果是普通的删除，有rrtype，可以这样缩短复杂度
		rrtype := delCrr.Header().Rrtype
		crrs := e.m[rrtype]
		e.deleteCrr(delCrr, crrs, rrtype)
	}
}

func (e *Elem) deleteCrr(delCrr CRR, crrs []CRR, rrtype uint16) bool {
	for index, memCrr := range crrs {
		if delCrr.RRId != memCrr.RRId {
			continue
		}
		crrs[index] = crrs[len(crrs)-1]
		e.m[rrtype] = crrs[:len(crrs)-1]
		if len(e.m[rrtype]) == 0 {
			delete(e.m, rrtype)
		}
		return true
	}
	return false
}

// Less is a tree helper function that calls less.
func Less(a *Elem, name string) int { return less(name, a.Name()) }

func wrr(crrs []CRR) int {
	var sum int16
	var res int
	for _, crr := range crrs {
		sum += crr.Weight
	}
	rand.Seed(time.Now().UnixNano())
	rd := rand.Intn(int(sum)) + 1
	var s int16
	for i, crr := range crrs {
		s += crr.Weight
		if s >= int16(rd) {
			res = i
			break
		}
	}
	return res
}
