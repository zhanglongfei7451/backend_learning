package tree

import (
	"github.com/miekg/dns"
	"math"
	"math/rand"
	"net"
	"testing"
	"time"
)

func TestWrrCorrect(t *testing.T) {
	crrList := mockCrr()
	var resList []int
	for i := 0; i < 100000; i++ {
		res := wrr(crrList)
		//res := wrr2(len(crrList), crrList)
		resList = append(resList, res)
	}

	// 测试50%的这种负载情况的准确性
	var cnt int
	for _, res := range resList {
		if res == 5 { // 第5个元素配置的50%
			cnt++
		}
	}
	diff := math.Abs(float64(cnt/1000 - 50)) // 转换时存在一点点的误差
	if diff > 5 {                            // 误差要小于5%
		t.Fatal("lb radio has more difference")
	}

	// 测试10%的这种负载情况的准确性
	cnt = 0
	for _, res := range resList {
		if res == 0 {
			cnt++
		}
	}
	diff = math.Abs(float64(cnt/1000 - 10)) // 转换时存在一点点的误差
	if diff > 5 {                           // 误差要小于5%
		t.Fatal("lb radio has more difference")
	}

}

func BenchmarkWrr2(b *testing.B) {
	crrList := mockCrrForBenchmark()
	b.ReportAllocs()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		wrr2(len(crrList), crrList)
	}
}

func BenchmarkWrr(b *testing.B) {
	crrList := mockCrrForBenchmark()
	b.ReportAllocs()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		wrr(crrList)
	}
}

func mockCrrForBenchmark() []CRR {
	crrList := []CRR{}
	for i := 0; i < 10; i++ {
		crrList = append(crrList, CRR{
			RRId: "0", LineId: "0", Weight: int16(rand.Intn(30)), Enabled: true, RR: &dns.A{ //nolint:gosec
				Hdr: dns.RR_Header{},
				A:   net.ParseIP("1.1.1.0"),
			}})
	}
	return crrList
}

func mockCrr() []CRR {
	crrList := []CRR{
		{
			RRId: "0", LineId: "0", Weight: 10, Enabled: true, RR: &dns.A{
				Hdr: dns.RR_Header{},
				A:   net.ParseIP("1.1.1.0"),
			},
		},
		{
			RRId: "1", LineId: "0", Weight: 10, Enabled: true, RR: &dns.A{
				Hdr: dns.RR_Header{},
				A:   net.ParseIP("1.1.1.1"),
			},
		},
		{
			RRId: "2", LineId: "0", Weight: 10, Enabled: true, RR: &dns.A{
				Hdr: dns.RR_Header{},
				A:   net.ParseIP("1.1.1.2"),
			},
		},
		{
			RRId: "3", LineId: "0", Weight: 10, Enabled: true, RR: &dns.A{
				Hdr: dns.RR_Header{},
				A:   net.ParseIP("1.1.1.3"),
			},
		},
		{
			RRId: "4", LineId: "0", Weight: 10, Enabled: true, RR: &dns.A{
				Hdr: dns.RR_Header{},
				A:   net.ParseIP("1.1.1.4"),
			},
		},
		{
			RRId: "5", LineId: "0", Weight: 50, Enabled: true, RR: &dns.A{
				Hdr: dns.RR_Header{},
				A:   net.ParseIP("1.1.1.5"),
			},
		},
	}
	return crrList
}

func wrr2(l int, crrs []CRR) int {
	/**
	关于权重算法介绍：https://www.codeleading.com/article/26355762048/
	把权重映射到数组中，使得下标和权重建立对映关系，使用前缀和数组
	在前缀和数组中找到第一个大于等于随机数的数的下标，这个下标就是所需要的
	*/
	// 构造前缀和数组
	prefix := make([]int16, l)
	prefix[0] = crrs[0].Weight
	for i := 1; i < l; i++ {
		prefix[i] = prefix[i-1] + crrs[i].Weight
	}
	rand.Seed(time.Now().UnixNano())
	target := int16(rand.Intn(int(prefix[l-1]))) + 1
	left, right := 0, l-1
	for left < right {
		mid := (right-left)>>2 + left
		if target <= prefix[mid] { // 找到左侧第一个 >= target 的值
			right = mid
		} else {
			left = mid + 1
		}
	}
	return left
}
