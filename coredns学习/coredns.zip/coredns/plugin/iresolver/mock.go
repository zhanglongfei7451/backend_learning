package iresolver

import (
	"context"
	. "github.com/coredns/coredns/plugin/manage"
	"github.com/coredns/coredns/plugin/test"
	"gorm.io/gorm"
)

// mock所需要的变量；读取sqllite中的数据并放入到iresolver的zone中
func Mock(db *gorm.DB) (*IResolver, context.Context) {
	ir := &IResolver{
		Next:     test.ErrorHandler(),
		Zones:    make(map[string]*Zone),
		transfer: nil,
	}
	var manage = &Manage{Db: db}
	manage.Updaters = append(manage.Updaters, ir)
	manage.InitIresolverForTest()
	ctx := context.TODO()
	db1, _ := db.DB()
	defer db1.Close()
	return ir, ctx
}
