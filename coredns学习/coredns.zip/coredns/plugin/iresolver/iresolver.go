// Package iresolver implements a intelligence mysql backend.
package iresolver

import (
	"context"
	"fmt"
	"strings"

	"github.com/coredns/coredns/plugin"
	clog "github.com/coredns/coredns/plugin/pkg/log"
	"github.com/coredns/coredns/plugin/transfer"
	"github.com/coredns/coredns/request"

	"github.com/miekg/dns"
)

var log = clog.NewWithPlugin("iresolver")

type (
	// IResolver is the plugin that can resolver domain with line and record weight
	IResolver struct {
		Next plugin.Handler
		// A map mapping zone (origin) to the Zone's data
		Zones    map[string]*Zone
		transfer *transfer.Transfer
	}
)

// ServeDNS implements the plugin.Handle interface.
func (ir IResolver) ServeDNS(ctx context.Context, w dns.ResponseWriter, r *dns.Msg) (int, error) {
	state := request.Request{W: w, Req: r}

	qname := state.Name()
	z := ir.FindBestZone(qname)
	if z == nil {
		return plugin.NextOrFailure(ir.Name(), ir.Next, ctx, w, r)
	}
	if !z.Enabled {
		return dns.RcodeServerFailure, nil
	}
	// If transfer is not loaded, we'll see these, answer with refused (no transfer allowed).
	if state.QType() == dns.TypeAXFR || state.QType() == dns.TypeIXFR {
		return dns.RcodeRefused, nil
	}

	// This is only for when we are a secondary zones.
	//if r.Opcode == dns.OpcodeNotify {
	//	if z.isNotify(state) {
	//		m := new(dns.Msg)
	//		m.SetReply(r)
	//		m.Authoritative = true
	//		w.WriteMsg(m)
	//
	//		log.Infof("Notify from %s for %s: checking transfer", state.IP(), z.origin)
	//		ok, err := z.shouldTransfer()
	//		if ok {
	//			z.TransferIn()
	//		} else {
	//			log.Infof("Notify from %s for %s: no SOA serial increase seen", state.IP(), z.origin)
	//		}
	//		if err != nil {
	//			log.Warningf("Notify from %s for %s: failed primary check: %s", state.IP(), z, err)
	//		}
	//		return dns.RcodeSuccess, nil
	//	}
	//	log.Infof("Dropping notify from %s for %s", state.IP(), z.origin)
	//	return dns.RcodeSuccess, nil
	//}

	//兼容是否使用geoip插件
	var lineIds []string
	if geoipLineIds, ok := ctx.Value("geoip/lineIds").([]string); ok {
		lineIds = geoipLineIds
	} else {
		lineIds = []string{"0"}
	}
	answer, ns, extra, result := z.Lookup(ctx, lineIds, state, qname)

	m := new(dns.Msg)
	m.SetReply(r)
	m.Authoritative = true
	m.Answer, m.Ns, m.Extra = answer, ns, extra

	switch result {
	case Success:
	case NoData:
	case NameError:
		m.Rcode = dns.RcodeNameError
	case Delegation:
		m.Authoritative = false
	case ServerFailure:
		// If the result is SERVFAIL and the answer is non-empty, then the SERVFAIL came from an
		// external CNAME lookup and the answer contains the CNAME with no target record. We should
		// write the CNAME record to the client instead of sending an empty SERVFAIL response.
		if len(m.Answer) == 0 {
			return dns.RcodeServerFailure, nil
		}
		//  The rcode in the response should be the rcode received from the target lookup. RFC 6604 section 3
		//参考上面92行的描述，当answer不为空时，说明时external查询导致，但是answer里面已经包含了cname记录值，应该把code设置success
		m.Rcode = dns.RcodeSuccess
	}

	err := w.WriteMsg(m)
	if err != nil {
		log.Errorf(err.Error())
	}
	return dns.RcodeSuccess, nil
}

// Name implements the Handler interface.
func (ir IResolver) Name() string { return "iresolver" }

type serialErr struct {
	err    string
	zone   string
	origin string
	serial int64
}

func (s *serialErr) Error() string {
	return fmt.Sprintf("%s for origin %s in iresolver %s, with %d SOA serial", s.err, s.origin, s.zone, s.serial)
}

func (ir IResolver) FindBestZone(qname string) *Zone {
	if len(qname) <= 1 || len(ir.Zones) == 0 {
		return nil
	}
	zone, ok := ir.Zones[qname]
	if ok {
		return zone
	}
	for {
		index := strings.IndexByte(qname, '.')
		if index < 0 {
			return nil
		}
		qname = qname[index+1:]
		if len(qname) <= 0 {
			return nil
		}
		zone, ok := ir.Zones[qname]
		if ok {
			return zone
		}
	}
}
