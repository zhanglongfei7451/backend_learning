package geoip

import (
	"github.com/coredns/coredns/plugin/manage"
	"testing"
)

type operateEntity struct {
	resourceType string
	operateType  string
	entity       interface{}
}

func TestUpdateDomain(t *testing.T) {
	resourceType := manage.DOMAIN
	d1 := &manage.Domain{DomainName: "example.com.", Enabled: true}
	d2 := &manage.Domain{DomainName: "example.com.", Enabled: false}

	tests := []struct {
		name    string
		operate []*operateEntity
		wantErr bool
	}{
		{
			name: "全流程测试",
			operate: []*operateEntity{
				{resourceType, manage.ADD, d1},
				{resourceType, manage.DISABLE, d2},
				{resourceType, manage.ENABLE, d1},
				{resourceType, manage.DELETE, d1},
			},
			wantErr: false,
		},
		{
			name: "重复新增/删除测试",
			operate: []*operateEntity{
				{resourceType, manage.ADD, d1},
				{resourceType, manage.ADD, d1},
				{resourceType, manage.DELETE, d1},
				{resourceType, manage.DELETE, d1},
				{resourceType, manage.DELETE, d2},
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			geoipTest, _ := newGeoIP(cityDBPath)
			for _, v := range tt.operate {
				if err := geoipTest.Update(v.resourceType, v.operateType, v.entity); (err != nil) != tt.wantErr {
					t.Errorf("Error: error = %v, wantErr %v", err, tt.wantErr)
				}
			}
		})
	}
}

func TestUpdateRecord(t *testing.T) {
	resourceType := manage.RECORD
	d1 := &manage.Domain{DomainName: "example1.com.", Enabled: false}
	rr11 := &manage.Record{DomainName: d1.DomainName, RecordId: "1", LineId: "20=1", Enabled: true}
	rr12 := &manage.Record{DomainName: d1.DomainName, RecordId: "1", LineId: "20=1", Enabled: false}
	rr13 := &manage.Record{DomainName: d1.DomainName, RecordId: "3", LineId: "999=1", Enabled: false}
	rr14 := &manage.Record{DomainName: d1.DomainName, RecordId: "4", LineId: "999=2", Enabled: false}
	rr15 := &manage.Record{DomainName: d1.DomainName, RecordId: "5", LineId: "998=1", Enabled: false}
	rr16 := &manage.Record{DomainName: d1.DomainName, RecordId: "6", LineId: "998=2", Enabled: false}

	tests := []struct {
		name        string
		initOperate []*operateEntity
		operate     []*operateEntity
		wantErr     bool
	}{
		{
			name: "全流程测试",
			initOperate: []*operateEntity{
				{manage.DOMAIN, manage.ADD, d1},
			},
			operate: []*operateEntity{
				{resourceType, manage.ADD, rr11},
				{resourceType, manage.ADD, rr13},
				{resourceType, manage.ADD, rr14},
				{resourceType, manage.ADD, rr15},
				{resourceType, manage.DISABLE, rr12},
				{resourceType, manage.ENABLE, rr11},
				{resourceType, manage.DELETE, rr11},
			},
			wantErr: false,
		},
		{
			name: "域名不存在时,增删启停解析记录",
			operate: []*operateEntity{
				{resourceType, manage.ADD, rr11},
				{resourceType, manage.ENABLE, rr11},
				{resourceType, manage.DISABLE, rr11},
				{resourceType, manage.DELETE, rr11},
			},
			wantErr: true,
		},
		{
			name: "重复新增已存在的解析记录",
			initOperate: []*operateEntity{
				{manage.DOMAIN, manage.ADD, d1},
			},
			operate: []*operateEntity{
				{resourceType, manage.ADD, rr11},
				{resourceType, manage.ADD, rr11},
			},
			wantErr: false,
		},
		{
			name: "用户线路配置",
			initOperate: []*operateEntity{
				{manage.DOMAIN, manage.ADD, d1},
			},
			operate: []*operateEntity{
				{resourceType, manage.ADD, rr13},
				{resourceType, manage.ADD, rr14},
				{resourceType, manage.DELETE, rr13},
				{resourceType, manage.ADD, rr15},
				{resourceType, manage.ADD, rr16},
				{resourceType, manage.DELETE, rr15},
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			geoipTest, _ := newGeoIP(cityDBPath)
			if tt.initOperate != nil {
				for _, v := range tt.initOperate {
					_ = geoipTest.Update(v.resourceType, v.operateType, v.entity)
				}
			}

			for _, v := range tt.operate {
				if err := geoipTest.Update(v.resourceType, v.operateType, v.entity); (err != nil) != tt.wantErr {
					t.Errorf("Error: error = %v, wantErr %v", err, tt.wantErr)
				}
			}
		})
	}
}

func TestUpdateCustomLine(t *testing.T) {
	resourceType := manage.CUSTOM_LINE
	c1 := &manage.CustomLine{LineId: "1", Ips: []string{"1.1.1.1-1.1.1.2", "2.2.2.2"}}
	c2 := &manage.CustomLine{LineId: "1", Ips: []string{"3.3.3.3"}}

	tests := []struct {
		name    string
		operate []*operateEntity
		wantErr bool
	}{
		{
			name: "全流程测试",
			operate: []*operateEntity{
				{resourceType, manage.ADD, c1},
				{resourceType, manage.UPDATE, c2},
				{resourceType, manage.DELETE, c1},
			},
			wantErr: false,
		},
		{
			name: "重复新增/删除测试",
			operate: []*operateEntity{
				{resourceType, manage.ADD, c1},
				{resourceType, manage.ADD, c1},
				{resourceType, manage.DELETE, c1},
				{resourceType, manage.DELETE, c1},
				{resourceType, manage.DELETE, c2},
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			geoipTest, _ := newGeoIP(cityDBPath)
			for _, v := range tt.operate {
				if err := geoipTest.Update(v.resourceType, v.operateType, v.entity); (err != nil) != tt.wantErr {
					t.Errorf("Error: error = %v, wantErr %v", err, tt.wantErr)
				}
			}
		})
	}
}

func TestUpdateLineGroup(t *testing.T) {
	resourceType := manage.LINE_GROUP
	l1 := &manage.LineGroup{LineId: "1", LineIds: []string{"20=1", "998=32"}}
	l2 := &manage.LineGroup{LineId: "1", LineIds: []string{"998=1"}}

	tests := []struct {
		name    string
		operate []*operateEntity
		wantErr bool
	}{
		{
			name: "全流程测试",
			operate: []*operateEntity{
				{resourceType, manage.ADD, l1},
				{resourceType, manage.UPDATE, l2},
				{resourceType, manage.DELETE, l1},
			},
			wantErr: false,
		},
		{
			name: "重复新增/删除测试",
			operate: []*operateEntity{
				{resourceType, manage.ADD, l1},
				{resourceType, manage.ADD, l1},
				{resourceType, manage.DELETE, l1},
				{resourceType, manage.DELETE, l1},
				{resourceType, manage.DELETE, l2},
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			geoipTest, _ := newGeoIP(cityDBPath)
			for _, v := range tt.operate {
				if err := geoipTest.Update(v.resourceType, v.operateType, v.entity); (err != nil) != tt.wantErr {
					t.Errorf("Error: error = %v, wantErr %v", err, tt.wantErr)
				}
			}
		})
	}
}

func TestInitIpdbLine(t *testing.T) {
	geoipTest, _ := newGeoIP(cityDBPath)
	ipdbLines := []*manage.IpdbLine{
		{"20", "陕西广电", "20=159"},
		{"20", "北京联通", "20=3"},
		{"15", "华中", "15=3"},
		{"10", "电信", "10=0"},
		{"AreaRegion", "广东", "华南"},
	}
	err := geoipTest.Update(manage.IPDB_LINE, manage.INIT, ipdbLines)
	if err != nil {
		t.Errorf("Error: error = %v", err)
	}
}

func TestConvertToIPRange(t *testing.T) {
	geoipTest, _ := newGeoIP(cityDBPath)
	tests := []struct {
		name     string
		rangeStr string
		wantErr  bool
	}{
		{"test1", "1.1.1.1-2.2.2.2", false},
		{"test2", "1.1.1.1", false},
		{"test3", " 1.1.1.9-2.2.2.2 ", false},
		{"test5", "1.1.1.1=2.2.2.2", true},
		{"test6", "", true},
		{"test7", "1.1.1.1--2.2.2.2", true},
		{"test8", "266.266.266.266", true},
		{"test9", "1.1.1.1-266.266.266.266", true},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			_, err := geoipTest.convertToIPRange(tt.rangeStr)
			if (err != nil) != tt.wantErr {
				t.Errorf("Error: error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}

func TestGetLineType(t *testing.T) {
	geoipTest, _ := newGeoIP(cityDBPath)
	tests := []struct {
		name    string
		lineId  string
		result  int
		wantErr bool
	}{
		{"test1", " 20=1 ", 20, false},
		{"test2", "7=2 ", 7, false},
		{"test3", " 999=2", 999, false},
		{"test3", "998=55423", 998, false},
		{"test4", "20==1", 1, true},
		{"test5", "3243543243", 1, true},
		{"test6", "=32", 1, true},
		{"test6", "", 1, true},
		{"test7", "1002=3", 1, true}, //越界
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			r, err := geoipTest.getLineType(tt.lineId)
			if (err != nil) != tt.wantErr {
				t.Errorf("Error: error = %v, wantErr %v", err, tt.wantErr)
			}
			if err == nil && r != tt.result {
				t.Errorf("Error: result = %v, wantResult %v", r, tt.result)
			}
		})
	}
}
