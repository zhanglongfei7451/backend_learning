package geoip

// 定时更新任务
func (g *GeoIP) execute() {
	err := g.cityReader.Reload(g.ipdbPath)
	if err != nil {
		log.Errorf("Ipdb数据库更新失败, Error: %v", err)
	} else {
		log.Infof("Ipdb数据库更新成功!")
	}
}
