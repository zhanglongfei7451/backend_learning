package geoip

import (
	"errors"
	"github.com/coredns/coredns/plugin/manage"
	"github.com/miekg/dns"
	"inet.af/netaddr"
	"strconv"
	"strings"
)

func (g *GeoIP) Update(resourceType string, operateType string, content interface{}) error {
	var err error
	switch resourceType {
	case manage.DOMAIN:
		err = g.dealDomain(operateType, content.(*manage.Domain))
	case manage.RECORD:
		err = g.dealRecord(operateType, content.(*manage.Record))
	case manage.CUSTOM_LINE:
		err = g.dealCustomLine(operateType, content.(*manage.CustomLine))
	case manage.LINE_GROUP:
		err = g.dealLineGroup(operateType, content.(*manage.LineGroup))
	case manage.IPDB_LINE:
		err = g.dealIpdbLine(operateType, content.([]*manage.IpdbLine))
	default:
		return nil
	}
	return err
}

func (g *GeoIP) dealDomain(operateType string, domain *manage.Domain) error {
	domainName := domain.DomainName
	switch operateType {
	case manage.ADD:
		g.domains[domainName] = newDomainLine(domain.Enabled)
	case manage.DELETE:
		delete(g.domains, domainName)
	case manage.ENABLE, manage.DISABLE:
		if entity, isOk := g.domains[domainName]; isOk {
			entity.enabled = domain.Enabled
		} else {
			return errors.New("域名不存在，启停失败")
		}
	}
	return nil
}

func (g *GeoIP) dealRecord(operateType string, record *manage.Record) error {
	if operateType == manage.ADD && record.Enabled == false {
		return nil
	}
	if record.RType != dns.TypeNone && record.LineId == defaultLineId { // 非update_delete(通过RType判断)并且是默认线路
		return nil
	}
	domain, isOk := g.domains[record.DomainName]
	if !isOk {
		return errors.New("域名不存在")
	}
	var (
		rlType   int
		lineType *LineType
		err      error
	)
	if operateType == manage.DELETE && record.LineId == "" { // update_delete情况解析不到lineType
		lineType, rlType = g.getLineTypeForDelete(record)
	} else {
		rlType, err = g.getLineType(record.LineId)
		if err != nil {
			return err
		}
		lineType = domain.types[rlType]
	}

	switch operateType {
	case manage.ADD, manage.ENABLE:
		// update domain's lineType
		if lineType == nil {
			lineType = newLineType()
		}
		lineType.recordLineMap[record.RecordId] = record.LineId
		domain.types[rlType] = lineType

		// update domain's dCustoms and dGroups
		if rlType == customLineFlag {
			domain.dCustoms[record.LineId] = true
		} else if rlType == lineGroupFlag {
			domain.dGroups[record.LineId] = true
		}
	case manage.DISABLE, manage.DELETE:
		if lineType == nil {
			return nil
		}
		// update domain's lineType
		delete(lineType.recordLineMap, record.RecordId)
		if len(lineType.recordLineMap) <= 0 {
			domain.types[rlType] = nil
		} else {
			domain.types[rlType] = lineType
		}

		// update domain's dCustoms and dGroups
		if rlType == customLineFlag {
			delete(domain.dCustoms, record.LineId)
		} else if rlType == lineGroupFlag {
			delete(domain.dGroups, record.LineId)
		}
	}
	return nil
}

func (g *GeoIP) dealCustomLine(operateType string, cl *manage.CustomLine) error {
	switch operateType {
	case manage.ADD, manage.UPDATE:
		if cl.Ips == nil {
			return errors.New("CustomLine配置错误: " + cl.LineId)
		}
		var ipRange []*netaddr.IPRange
		for _, i := range cl.Ips {
			tmp, err := g.convertToIPRange(i)
			if err != nil {
				log.Errorf("转为IpRange实体错误:%v", err)
				continue
			}
			ipRange = append(ipRange, tmp)
		}
		g.customs[cl.LineId] = ipRange
	case manage.DELETE:
		delete(g.customs, cl.LineId)
	}
	return nil
}

func (g *GeoIP) dealLineGroup(operateType string, lg *manage.LineGroup) error {
	switch operateType {
	case manage.ADD, manage.UPDATE:
		g.groups[lg.LineId] = lg.LineIds
	case manage.DELETE:
		delete(g.groups, lg.LineId)
	}
	return nil
}

func (g *GeoIP) dealIpdbLine(operateType string, ils []*manage.IpdbLine) error {
	switch operateType {
	case manage.INIT:
		for _, i := range ils {
			if _, isOk := g.ipdbLineMap[i.LineType]; !isOk {
				g.ipdbLineMap[i.LineType] = make(map[string]string)
			}
			g.ipdbLineMap[i.LineType][i.Key] = i.Value
		}
	}
	return nil
}

// convertToIPRange 输入"1.1.1.1-2.2.2.2" "1.1.1.1"  " " 输出IpRange
func (g *GeoIP) convertToIPRange(s string) (*netaddr.IPRange, error) {
	s = strings.TrimSpace(s)
	l := len(strings.Split(s, ipRangeSplit))
	if l != 1 && l != 2 {
		return nil, errors.New(s + "IP段格式错误")
	}
	if l == 1 {
		s = s + ipRangeSplit + s
	}
	result, err := netaddr.ParseIPRange(s)
	return &result, err
}

// getLineType. 输入"20=8",输出20. 输入"999=8",输999. 输入"273947354323", 输出error
func (g *GeoIP) getLineType(lineId string) (int, error) {
	parts := strings.Split(lineId, lineTypeSplit)
	if len(parts) != 2 || len(parts[0]) <= 0 {
		return -1, errors.New("线路无法解析类型. lineId:" + lineId)
	}
	lineType, err := strconv.Atoi(strings.TrimSpace(parts[0]))
	if lineType >= maxLineType {
		return -1, errors.New("线路" + lineId + "无法解析类型")
	}
	return lineType, err
}

// getLineTypeForDelete delete record 时，遍历寻找LineType
func (g *GeoIP) getLineTypeForDelete(record *manage.Record) (*LineType, int) { // delete只提供domainName recordId rName, 因此需要遍历寻找
	domain := g.domains[record.DomainName]
	for _, t := range supportLineTypes {
		lineType := domain.types[t]
		if lineType == nil {
			continue
		}
		if _, isOk := lineType.recordLineMap[record.RecordId]; isOk {
			return lineType, t
		}
	}
	return nil, -1
}
