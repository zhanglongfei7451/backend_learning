// Package geoip implements a max mind database plugin.
package geoip

import (
	"context"
	"github.com/coredns/coredns/plugin"
	clog "github.com/coredns/coredns/plugin/pkg/log"
	"github.com/coredns/coredns/request"
	"github.com/ipipdotnet/ipdb-go"
	"github.com/miekg/dns"
	"inet.af/netaddr"
	"strconv"
	"strings"
	"time"
)

const (
	areaRegion            = "AreaRegion"   // 大区和省份的对照关系
	ipdbLanguage          = "CN"           // ipdb库读取的默认语言
	lineTypeSplit         = "="            // lineType 命名的分隔符
	ipRangeSplit          = "-"            // 自定义线路间隔的分隔符
	defaultReloadInterval = 12 * time.Hour // 默认的file reload 时间间隔
	defaultLineId         = "0"            // 默认线路的lineId
	maxLineType           = 1000           // lineType的最大下标，目前是customLineFlag
	customLineFlag        = 999            // 自定义线路标志
	lineGroupFlag         = 998            // 线路分组标志
	regionIspFlag         = 20             // 省+运营商  省+云厂商  港澳台
	ispFlag               = 10             // 运营商  云厂商
	domesticFlag          = 7              // 境内
	abroadFlag            = 3              // 境外
	countryFlag           = 6              //
	areaFlag              = 15             // 大区 港澳台地区
	areaIspFlag           = 16             // 大区+运营商
	continentFlag         = 5              // 7大洲
	YD                    = "移动"
	DX                    = "电信"
	LT                    = "联通"
)

var log = clog.NewWithPlugin(pluginName)
var supportLineTypes = []int{regionIspFlag, areaIspFlag, areaFlag, ispFlag, domesticFlag, countryFlag, continentFlag, abroadFlag, customLineFlag, lineGroupFlag}
var domainCloudMap = map[string]string{
	"azure-tech.com": "微软Azure",
	"netease.com":    "网易云",
	"amazon.com":     "亚马逊云",
	"qingcloud.com":  "青云",
	"ucloud.cn":      "UCloud",
	"baidu.com":      "百度云",
	"huawei.com":     "华为云",
	"aliyun.com":     "阿里云",
	"tencent.com":    "腾讯云",
}

// GeoIP is a plugin that add geo location data to the request context by looking up ipdb file
// geoIP2 database, and which data can be later consumed by other middlewares.
type GeoIP struct {
	Next           plugin.Handler
	cityReader     *ipdb.City
	reloadInterval time.Duration                 // file reload 时间间隔
	ipdbPath       string                        // ipdb 数据库所在目录
	domains        map[string]*DomainLine        // {"ecloud.cn" -> DomainLine, ...}
	customs        map[string][]*netaddr.IPRange // 自定义线路 数据库的配置信息. [ipRange1, ipRange2]. ipRange1样例 1.1.1.1-2.2.2.2/2.2.2.2-2.2.2.2
	groups         map[string][]string           // 线路分组 数据库的配置信息
	ipdbLineMap    map[string]map[string]string  // ipdb和dnspod线路对应关系(内容源于dns_ipdb_line表). line_type => {key=>value} 样例: 20=>{"天津电信"=>20=52}
}

type DomainLine struct {
	types    [maxLineType]*LineType // 域名包含的各线路类型情况, [{20,xx},{10,xx},{999,xx}]
	enabled  bool                   // 域名是否被停用
	dCustoms map[string]bool        // 域名使用的自定义线路
	dGroups  map[string]bool        // 域名使用的线路分组
}

type LineType struct {
	recordLineMap map[string]string // recordId -> lineId. {"recordId1"->"20=1","recordId2"->"20=5","recordId3"->"20=10"}
}

type CityIpdb struct {
	ip            string // ip
	countryName   string // 国家名
	regionName    string // 省份名字
	ispDomain     string // 运营商
	countryCode   string // 国家2位代码
	continentCode string // 大洲代码
	areaName      string // 大区
	line          string // 线路
}

// ServeDNS implements the plugin.Handler interface.
func (g GeoIP) ServeDNS(ctx context.Context, w dns.ResponseWriter, r *dns.Msg) (int, error) {
	state := request.Request{W: w, Req: r}
	qname := state.Name()
	domain, domainName := g.FindBestZone(qname)
	var lineIds []string
	if domain == nil || !domain.enabled || // 域名不存在或已被停用
		state.QType() == dns.TypeSOA || (state.QType() == dns.TypeNS && domainName == qname) || //SOA NS
		state.QType() == dns.TypeAXFR || state.QType() == dns.TypeIXFR {
		lineIds = []string{defaultLineId}
	} else {
		srcIp := getSrcIp(state)
		lineIds = append(g.parse(domain, srcIp), defaultLineId)
	}
	ctx = context.WithValue(ctx, pluginName+"/lineIds", lineIds)
	return plugin.NextOrFailure(pluginName, g.Next, ctx, w, r)
}

func getSrcIp(state request.Request) string {
	o := state.Req.IsEdns0()
	if o == nil {
		return state.IP()
	}
	for _, s := range o.Option {
		if e, ok := s.(*dns.EDNS0_SUBNET); ok {
			return e.Address.String()
		}
	}
	return state.IP()
}

// Name implements the Handler interface.
func (g GeoIP) Name() string { return pluginName }

// parse 根据域名和ip, 解析出符合的lineIds
func (g GeoIP) parse(domain *DomainLine, ip string) []string {
	var (
		cityIpdb                *CityIpdb
		defaultLines, userLines []string //符合要求的默认线路、用户线路
		okTypes                 = make(map[int]bool)
	)
	for _, t := range supportLineTypes {
		if domain.types[t] == nil {
			continue
		}
		if t < lineGroupFlag { // 默认线路
			if cityIpdb == nil {
				cityIpdb = g.newCityIpdb(ip)
			}
			defaultLines = append(defaultLines, g.parseDefault(t, cityIpdb)...)
		} else if t == customLineFlag { // 执行次数 <= 1
			userLines = append(userLines, g.parseCustom(domain.dCustoms, ip)...)
		} else if t == lineGroupFlag { // 执行次数 <= 1
			var okLines = make(map[string]bool)
			for _, l := range append(defaultLines, userLines...) {
				okLines[l] = true
			}
			if cityIpdb == nil {
				cityIpdb = g.newCityIpdb(ip)
			}
			userLines = append(userLines, g.parseLineGroup(domain, okLines, okTypes, cityIpdb)...)
		}
		okTypes[t] = true
	}
	return append(userLines, defaultLines...)
}

// parseDefault 解析已有线路(dnspod)，包括ISP、省份、大区、境内外等
func (g GeoIP) parseDefault(rType int, i *CityIpdb) []string {
	var results []string
	if i == nil {
		return results
	}
	switch rType { // TODO 优化: regionIspFlag areaIspFlag areaFlag 发现countryName不是中国，可以直接return
	case regionIspFlag, areaIspFlag, areaFlag, ispFlag, countryFlag, continentFlag:
		il, isOk := g.ipdbLineMap[strconv.Itoa(rType)]
		if !isOk {
			return results
		}
		var key []string
		switch rType {
		case regionIspFlag: // 省+运营商 或 省+云厂商
			key = []string{}
			if i.regionName == "香港" || i.regionName == "澳门" || i.regionName == "台湾" { //港澳台特殊处理
				key = []string{i.countryName + i.regionName}
			} else {
				// ispDomain 信息识别
				cloudName, exist := domainCloudMap[i.ispDomain]
				if exist {
					key = append(key, i.regionName+cloudName)
				}
				// line 信息识别
				lines := strings.Split(i.line, "/")
				for _, line := range lines {
					key = append(key, i.regionName+line)
				}
			}
		case areaIspFlag: // 大区+运营商 (大区无港澳台联动)
			key = []string{}
			if strings.Contains(i.line, YD) {
				key = append(key, i.areaName+YD)
			}
			if strings.Contains(i.line, LT) {
				key = append(key, i.areaName+LT)
			}
			if strings.Contains(i.line, DX) {
				key = append(key, i.areaName+DX)
			}
		case areaFlag: // 大区/港澳台地区  只有中国才有这个线路赋值
			key = []string{i.areaName}
		case ispFlag: // 运营商或云厂商  line与isp_domain. 备注: "联通/电信/移动/铁通"多线路的情况，赋多个lineId
			key = strings.Split(i.line, "/")
			cloudName, exist := domainCloudMap[i.ispDomain]
			if exist {
				key = append(key, cloudName)
			}
		case countryFlag: // 国家
			key = []string{i.countryCode}
		case continentFlag: // 大洲. dns_ipdb_line表中映射关系 line_type = "5"
			key = []string{i.continentCode}
		}
		for _, k := range key {
			lineId, isOk := il[k]
			if isOk {
				results = append(results, lineId)
			}
		}
	case abroadFlag: // 境外, 港澳台属于境外
		if i.countryCode != "CN" {
			return []string{"3=0"}
		}
	case domesticFlag: // 境内
		if i.countryCode == "CN" {
			return []string{"7=0"}
		}
	}
	return results
}

// parseCustom 解析自定义线路. 返回符合要求的lineIds.
//             customIds: 待check的线路Id.
//             ip: 源IP
func (g GeoIP) parseCustom(customIds map[string]bool, ip string) []string {
	var results []string
	if len(customIds) <= 0 {
		return results
	}

	nIp, err := netaddr.ParseIP(ip)
	if err != nil {
		log.Errorf("源IP解析错误. IP:" + ip)
		return results
	}

	for customId := range customIds {
		if g.checkCustom(customId, nIp) {
			results = append(results, customId)
		}
	}
	return results
}

// checkCustom check源IP是否符合的自定义线路customId的配置. 若符合，返回true, 否则返回false
//             customId: 待检测的自定义线路
//             ip:源IP
func (g GeoIP) checkCustom(customId string, ip netaddr.IP) bool {
	ipRanges, isOk := g.customs[customId]
	if !isOk {
		log.Errorf("自定义线路未配置, LineId:" + customId)
		return false
	}
	for _, ir := range ipRanges {
		if ir.Contains(ip) {
			return true
		}
	}
	return false
}

// parseLineGroup 解析线路分组. 返回符合要求的lineIds.
//                okLines 已符合的线路Id
//                dLineGroups 待检测的groupId
func (g GeoIP) parseLineGroup(domain *DomainLine, okLines map[string]bool, okTypes map[int]bool, i *CityIpdb) []string {
	var (
		results     []string
		check       bool
		dLineGroups = domain.dGroups
	)
	if len(dLineGroups) <= 0 {
		return results
	}
	for groupId := range dLineGroups {
		check, okLines, okTypes = g.checkLineGroup(domain, groupId, okLines, okTypes, i)
		if check {
			results = append(results, groupId)
		}
	}
	return results
}

// checkLineGroup check 线路分组groupId是否符合配置. 若符合，返回true, 否则返回false. 只要groupId中有一个item符合，则返回true
//                okLines 检测过，已满足的lineIds
//                okTypes 已检测过的types
func (g GeoIP) checkLineGroup(domain *DomainLine, groupId string, okLines map[string]bool, okTypes map[int]bool, i *CityIpdb) (bool, map[string]bool, map[int]bool) {
	group, isOk := g.groups[groupId]
	if !isOk {
		log.Errorf("线路分组未配置, LineId:" + groupId)
		return false, okLines, okTypes
	}
	for _, item := range group { // group样例：[15=2,20=7,999=4], 只要有一项item满足，则该线路分组满足
		if _, isOk := okLines[item]; isOk {
			return true, okLines, okTypes
		}
		// 1.配置的线路有误，无法解析类型 2. 线路分组不允许嵌套
		rType, err := g.getLineType(item)
		if err != nil || rType == lineGroupFlag {
			continue
		}
		// 默认线路rType类型已检测过，item却未被加入过okLines
		if isOk := okTypes[rType]; isOk && rType != customLineFlag {
			continue
		}
		// 自定义线路已检测过，item却未被加入过okLines
		if rType == customLineFlag && domain.dCustoms[item] {
			continue
		}

		// 未被校验过的类型, 普通线路/自定义线路
		var ltypeOkLines []string
		if rType == customLineFlag {
			customIds := map[string]bool{item: true}
			ltypeOkLines = g.parseCustom(customIds, i.ip)
		} else {
			ltypeOkLines = g.parseDefault(rType, i)
		}

		okTypes[rType] = true
		for _, l := range ltypeOkLines {
			okLines[l] = true
		}
		if _, isOk := okLines[item]; isOk {
			return true, okLines, okTypes
		} else {
			continue
		}
	}
	return false, okLines, okTypes
}

func newGeoIP(dbPath string) (*GeoIP, error) {
	cityReader, err := ipdb.NewCity(dbPath)
	if err != nil {
		log.Fatal(err)
		return nil, err
	}
	domains := make(map[string]*DomainLine)
	customs := make(map[string][]*netaddr.IPRange)
	groups := make(map[string][]string)
	ipdbLineMap := make(map[string]map[string]string)
	return &GeoIP{cityReader: cityReader, ipdbPath: dbPath, domains: domains, customs: customs, groups: groups, ipdbLineMap: ipdbLineMap}, nil
}

func newDomainLine(enabled bool) *DomainLine {
	types := [maxLineType]*LineType{}
	dCustoms := make(map[string]bool)
	dGroups := make(map[string]bool)
	return &DomainLine{enabled: enabled, types: types, dCustoms: dCustoms, dGroups: dGroups}
}

func newLineType() *LineType {
	return &LineType{recordLineMap: make(map[string]string)}
}

// getIpdb 根据源IP，获取ipdb实体
func (g GeoIP) newCityIpdb(ip string) *CityIpdb {
	cityMap, err := g.cityReader.FindMap(ip, ipdbLanguage)
	if err != nil {
		return nil
	}
	i := &CityIpdb{
		ip:            ip,
		countryName:   cityMap["country_name"],
		regionName:    cityMap["region_name"],
		ispDomain:     cityMap["isp_domain"],
		countryCode:   cityMap["country_code"],
		continentCode: cityMap["continent_code"],
		line:          cityMap["line"],
	}
	// areaName 大区赋值
	areaRegionMap, isOk := g.ipdbLineMap[areaRegion]
	if isOk {
		i.areaName = areaRegionMap[i.regionName]
	}
	return i
}

func (g GeoIP) FindBestZone(qname string) (*DomainLine, string) { // 逻辑与iresolver的FindBestZone一致
	if len(qname) <= 1 {
		return nil, qname
	}
	dl, ok := g.domains[qname]
	if ok {
		return dl, qname
	}
	for {
		index := strings.IndexByte(qname, '.')
		if index < 0 {
			return nil, qname
		}
		qname = qname[index+1:]
		if len(qname) <= 0 {
			return nil, qname
		}
		dl, ok := g.domains[qname]
		if ok {
			return dl, qname
		}
	}
}

func (g *GeoIP) startTicker(executeChan chan bool) error {
	if g.reloadInterval == 0 {
		g.reloadInterval = defaultReloadInterval
	}
	go func() {
		ticker := time.NewTicker(g.reloadInterval)
		for {
			select {
			case <-executeChan:
				return
			case <-ticker.C:
				g.execute()
			}
		}
	}()
	return nil
}

func (g *GeoIP) stopTicker(executeChan chan bool) error {
	close(executeChan)
	return nil
}
