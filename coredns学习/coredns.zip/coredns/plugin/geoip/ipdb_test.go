package geoip

import (
	"fmt"
	"os"
	"strconv"
	"testing"
)

// IpdbToCsv 读取ipdb每个字段的全量取值， 用于对照dnspod的line命名.
//  4G 2core 虚机执行时间约 3.71s
//  执行结果输出到ipdb_ipv4_full.csv文件
/** 读取的字段参考 ipdb package 中的CityInfo实体
  CountryName	string	`json:"country_name"`  // 国家名、骨干网、域名、保留地址. 备注: 港澳台 值为"中国", 与countryCode不一样
  RegionName string 	`json:"region_name"`  // 省名、中国(标注为中国的IP,如39.131.1.151, 大多字段null)
  CityName string 	`json:"city_name"`  // 城市名, 暂时用不到
  OwnerDomain string 	`json:"owner_domain"`  // null
  IspDomain string 	`json:"isp_domain"`   // 运营商的domain
  ChinaAdminCode string	`json:"china_admin_code"`  // null
  IddCode string 			`json:"idd_code"`  // 国际电话代码
  CountryCode string 		`json:"country_code"` // ISO_3166-1_alpha-2 中国为CN. 备注: 港HK澳MO台TW 与CountryName不一样
  ContinentCode string 	`json:"continent_code"` // 大洲 亚太（AP）/欧洲（EU）/北美（NA）/拉丁美洲（LA）/非洲（AF）/大洋洲（OA）/南极洲（AQ）
  IDC string 				`json:"idc"`   // null
  BaseStation string 		`json:"base_station"`   // null
  CountryCode3 string 	`json:"country_code3"`  // null
  EuropeanUnion string 	`json:"european_union"`  // null
  Line string `json:"line"`  // 运营商, 云厂商, 多种混合的现象
  Route string `json:"route"`   // null
  ASN string `json:"asn"`  // null
  ASNInfo []ASNInfo `json:"asn_info"`  // null
  AreaCode string `json:"area_code"`  // null

  ChinaRegionCode string `json:"china_region_code"`  // 省份code (实体内无该字段，但有赋值)
  ChinaCityCode string `json:"china_city_code"`  // city code (实体内无该字段，但有赋值)
*/
func IpdbToCsv(t *testing.T) {
	var (
		g, _ = newGeoIP(cityDBPath)
		mask = 255
		// ip全量数据过大, 可设置步长, 达到简洁的全量分析的目的
		i1Step = 2
		i2Step = 5
		i3Step = 10
		i4Step = 50
	)

	ipdbfile, err := os.Create("ipdb_ipv4_full.csv")
	if err != nil {
		fmt.Println("create file fail")
	}
	defer ipdbfile.Close()
	_, _ = ipdbfile.WriteString("ip,countryName,regionName,cityName,ownerDomain,ispDomain,chinaAdminCode,iddCode,countryCode,continentCode,idc,baseStation,countryCode3,europeanUnion,line,route,asn,asnInfo,areaCode,chinaRegionCode,chinaCityCode\n")

	for i1 := 1; i1 <= mask; i1 = i1 + i1Step {
		for i2 := 1; i2 <= mask; i2 = i2 + i2Step {
			for i3 := 1; i3 <= mask; i3 = i3 + i3Step {
				for i4 := 1; i4 <= mask; i4 = i4 + i4Step {
					ip := strconv.Itoa(i1) + "." + strconv.Itoa(i2) + "." + strconv.Itoa(i3) + "." + strconv.Itoa(i4)
					r, _ := g.cityReader.FindMap(ip, ipdbLanguage)
					_, _ = ipdbfile.WriteString(ip + "," + r["country_name"] + "," + r["region_name"] + "," + r["city_name"] + "," + r["owner_domain"] + "," + r["isp_domain"] + "," + r["china_admin_code"] + "," + r["idd_code"] + "," + r["country_code"] + "," + r["continent_code"] + "," + r["idc"] + "," + r["base_station"] + "," + r["country_code3"] + "," + r["european_union"] + "," + r["line"] + "," + r["route"] + "," + r["asn"] + "," + r["asn_info"] + "," + r["area_code"] + "," + r["china_region_code"] + "," + r["china_city_code"] + "\n")
				}
			}
		}
	}
}
