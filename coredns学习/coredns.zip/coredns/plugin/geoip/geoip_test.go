package geoip

import (
	"github.com/coredns/coredns/plugin/manage"
	"gorm.io/driver/sqlite"
	"gorm.io/gorm"
	"testing"
)

var testIpMap = map[string]string{ // key 命名 ISO3166-2_isp
	"usa":   "3.16.51.101",     //美国
	"fr":    "77.192.1.2",      //法国
	"ca":    "50.64.1.3",       //加拿大
	"khm":   "111.67.96.1",     //柬埔寨
	"js_yd": "221.130.0.1",     // 江苏、移动、华东
	"gx_yd": "218.204.0.2",     // 广西、移动、华南
	"cq_yd": "218.206.0.1",     // 重庆、移动、西南
	"sn_yd": "1.80.2.1",        // 陕西、电信、西北
	"nm_yd": "1.180.1.1",       // 内蒙古、移动、华北
	"ha_yd": "211.142.128.2",   // 河南、移动、华中
	"hl_yd": "1.56.0.1",        // 黑龙江、电信、东北
	"hk":    "223.255.249.117", //香港
	"mo":    "161.64.1.2",      //澳门
	"tw":    "111.80.1.2",      //台湾
}

func TestParse(t *testing.T) {
	db, _ := gorm.Open(sqlite.Open("test.db"), &gorm.Config{})
	var ipdbLines []*manage.IpdbLine
	_ = db.Find(&ipdbLines)

	d1 := &manage.Domain{DomainName: "example1.com.", Enabled: true}
	dop1 := &operateEntity{manage.DOMAIN, manage.ADD, d1}
	qname1 := "www." + d1.DomainName
	// 默认线路
	rr11 := &manage.Record{DomainName: d1.DomainName, RecordId: "1_1", LineId: "3=0", Enabled: true}
	rr12 := &manage.Record{DomainName: d1.DomainName, RecordId: "1_2", LineId: "7=0", Enabled: true}
	rr13 := &manage.Record{DomainName: d1.DomainName, RecordId: "1_3", LineId: "15=3", Enabled: true}
	rr14 := &manage.Record{DomainName: d1.DomainName, RecordId: "1_4", LineId: "20=1", Enabled: true}
	rr15 := &manage.Record{DomainName: d1.DomainName, RecordId: "1_5", LineId: "16=2", Enabled: true}
	rr16 := &manage.Record{DomainName: d1.DomainName, RecordId: "1_6", LineId: "6=2", Enabled: true}
	rop11 := &operateEntity{manage.RECORD, manage.ADD, rr11}
	rop12 := &operateEntity{manage.RECORD, manage.ADD, rr12}
	rop13 := &operateEntity{manage.RECORD, manage.ADD, rr13}
	rop14 := &operateEntity{manage.RECORD, manage.ADD, rr14}
	rop15 := &operateEntity{manage.RECORD, manage.ADD, rr15}
	rop16 := &operateEntity{manage.RECORD, manage.ADD, rr16}

	//自定义线路
	rr21 := &manage.Record{DomainName: d1.DomainName, RecordId: "2_1", LineId: "999=1", Enabled: true}
	rr22 := &manage.Record{DomainName: d1.DomainName, RecordId: "2_2", LineId: "999=2", Enabled: true}
	rr23 := &manage.Record{DomainName: d1.DomainName, RecordId: "2_3", LineId: "999=3", Enabled: true}
	rr24 := &manage.Record{DomainName: d1.DomainName, RecordId: "2_4", LineId: "999=3", Enabled: true}
	rop21 := &operateEntity{manage.RECORD, manage.ADD, rr21}
	rop22 := &operateEntity{manage.RECORD, manage.ADD, rr22}
	rop23 := &operateEntity{manage.RECORD, manage.ADD, rr23}
	rop24 := &operateEntity{manage.RECORD, manage.ADD, rr24}

	cl1 := &manage.CustomLine{LineId: "999=1", Ips: []string{"", "218.204.0.2", "221.127.9.9-221.145.7.7"}}                // 部分空配置
	cl2 := &manage.CustomLine{LineId: "999=2", Ips: []string{"1.1.1.1-2.2.2.2", "221.130.0.1", "221.130.0.0-221.130.9.9"}} //部分符合
	cl3 := &manage.CustomLine{LineId: "999=3", Ips: []string{"1.1.1.1-1.1.1.2", "1.1.1.3", "3.3.3.3"}}                     //均不符合
	cl4 := &manage.CustomLine{LineId: "999=4", Ips: []string{"218.204.0.2"}}
	cl5 := &manage.CustomLine{LineId: "999=5", Ips: []string{}} // 空配置
	cl6 := &manage.CustomLine{LineId: "999=6", Ips: []string{}} // 符合，但解析线路中没有配它

	// 线路分组. 测试IP:221.130.0.1(江苏、移动、华东) 符合的线路:7=0 15=2 20=69 16=11 6=48 998=1 998=2
	rr31 := &manage.Record{DomainName: d1.DomainName, RecordId: "3_1", LineId: "998=1", Enabled: true}
	rr32 := &manage.Record{DomainName: d1.DomainName, RecordId: "3_2", LineId: "998=2", Enabled: true}
	rr33 := &manage.Record{DomainName: d1.DomainName, RecordId: "3_3", LineId: "998=3", Enabled: true}
	rr34 := &manage.Record{DomainName: d1.DomainName, RecordId: "3_4", LineId: "998=4", Enabled: true}
	rr35 := &manage.Record{DomainName: d1.DomainName, RecordId: "3_5", LineId: "998=5", Enabled: true}
	rop31 := &operateEntity{manage.RECORD, manage.ADD, rr31}
	rop32 := &operateEntity{manage.RECORD, manage.ADD, rr32}
	rop33 := &operateEntity{manage.RECORD, manage.ADD, rr33}
	rop34 := &operateEntity{manage.RECORD, manage.ADD, rr34}
	rop35 := &operateEntity{manage.RECORD, manage.ADD, rr35}

	lg1 := &manage.LineGroup{LineId: "998=1", LineIds: []string{}}                        // 空配置
	lg2 := &manage.LineGroup{LineId: "998=2", LineIds: []string{"20=39", "20=35"}}        // 纯default,均不符合
	lg3 := &manage.LineGroup{LineId: "998=3", LineIds: []string{"3=0", "20=32", "20=69"}} // 纯default,部分不符合

	lg4 := &manage.LineGroup{LineId: "998=4", LineIds: []string{"20=32", "999=3", "999=4"}} // 均不符合, 998=4自定义线路未配置
	lg5 := &manage.LineGroup{LineId: "998=5", LineIds: []string{"20=32", "999=1", "999=4"}} // 部分符合

	type queryEntity struct {
		ip      string
		results []string
	}
	tests := []struct {
		name        string
		initOperate []*operateEntity
		qname       string
		query       []*queryEntity
		customLine  []*manage.CustomLine
		lineGroup   []*manage.LineGroup
	}{
		{
			name:        "test1_1", //默认线路测试_境内境外(3/7)
			qname:       qname1,
			initOperate: []*operateEntity{dop1, rop11, rop12},
			query: []*queryEntity{
				{ip: testIpMap["js_yd"], results: []string{"7=0"}}, //境内
				{ip: testIpMap["usa"], results: []string{"3=0"}},   //境外
				{ip: testIpMap["tw"], results: []string{"3=0"}},    //台湾 、境内
				{ip: testIpMap["mo"], results: []string{"3=0"}},    //澳门、境内
				{ip: testIpMap["hk"], results: []string{"3=0"}},    //香港、境内
			},
		},
		{
			name:        "test1_2", //默认线路测试_大区/港澳台地区 (15)
			qname:       qname1,
			initOperate: []*operateEntity{dop1, rop13},
			query: []*queryEntity{
				{ip: testIpMap["js_yd"], results: []string{"15=2"}}, // 江苏、华东
				{ip: testIpMap["gx_yd"], results: []string{"15=4"}}, // 广西、华南
				{ip: testIpMap["cq_yd"], results: []string{"15=5"}}, // 重庆、西南
				{ip: testIpMap["sn_yd"], results: []string{"15=6"}}, // 陕西、西北
				{ip: testIpMap["nm_yd"], results: []string{"15=0"}}, // 内蒙古、华北
				{ip: testIpMap["ha_yd"], results: []string{"15=3"}}, // 河南、华中
				{ip: testIpMap["hl_yd"], results: []string{"15=1"}}, // 黑龙江、东北
				{ip: testIpMap["hk"], results: []string{"15=7"}},    // 香港、港澳台
				{ip: testIpMap["tw"], results: []string{"15=7"}},    //台湾 、港澳台
				{ip: testIpMap["mo"], results: []string{"15=7"}},    //澳门、港澳台
			},
		},
		{
			name:        "test1_3", // 默认线路测试_省+运营商、大区+运营商 (大区无港澳台联动) (20/16)
			qname:       qname1,
			initOperate: []*operateEntity{dop1, rop14, rop15},
			query: []*queryEntity{
				{ip: testIpMap["js_yd"], results: []string{"20=69", "16=11"}}, // 江苏、移动、华东
				{ip: testIpMap["gx_yd"], results: []string{"20=85", "16=19"}}, // 广西、移动、华南
				{ip: testIpMap["cq_yd"], results: []string{"20=78", "16=23"}}, // 重庆、移动、西南
				{ip: testIpMap["nm_yd"], results: []string{"20=36", "16=0"}},  // 内蒙古、电信、华北
				{ip: testIpMap["ha_yd"], results: []string{"20=74", "16=15"}}, // 河南、移动、华中
				{ip: testIpMap["hk"], results: []string{"20=62"}},             // 香港
				{ip: testIpMap["tw"], results: []string{"20=64"}},             //台湾
				{ip: testIpMap["mo"], results: []string{"20=63"}},             //澳门
			},
		},
		{
			name:        "test1_4", // 默认线路测试_国家 (6)
			qname:       qname1,
			initOperate: []*operateEntity{dop1, rop16},
			query: []*queryEntity{
				{ip: testIpMap["js_yd"], results: []string{"6=48"}}, // 江苏、中国
				{ip: testIpMap["usa"], results: []string{"6=231"}},  // 英国
				{ip: testIpMap["fr"], results: []string{"6=76"}},    // 法国
				{ip: testIpMap["ca"], results: []string{"6=38"}},    // 加拿大
				{ip: testIpMap["khm"], results: []string{"6=117"}},  // 柬埔寨
			},
		},
		{
			name: "test1_5", // 默认线路测试_isp (10) TODO 采购后补充
		},
		{
			name: "test1_6", // 默认线路测试_大洲 (5) TODO 采购后补充，
		},
		{
			name:        "test2_1", // 自定义线路
			qname:       qname1,
			initOperate: []*operateEntity{dop1, rop21, rop24},
			query: []*queryEntity{
				{ip: testIpMap["js_yd"], results: []string{"999=1"}}, // 221.130.0.1
			},
			customLine: []*manage.CustomLine{cl1, cl2, cl3, cl4, cl5, cl6},
		},
		{
			name:        "test2_2", // 自定义线路
			qname:       qname1,
			initOperate: []*operateEntity{dop1, rop22, rop23},
			query: []*queryEntity{
				{ip: testIpMap["js_yd"], results: []string{"999=2"}}, // 221.130.0.1
			},
			customLine: []*manage.CustomLine{cl1, cl2, cl3, cl4, cl5, cl6},
		},
		{
			name:        "test3_1", // 线路分组
			qname:       qname1,
			initOperate: []*operateEntity{dop1, rop11, rop12, rop13, rop21, rop23, rop31, rop32, rop33},
			query: []*queryEntity{
				{ip: testIpMap["js_yd"], results: []string{"999=1", "998=3", "15=2", "7=0"}}, // 221.130.0.1
			},
			customLine: []*manage.CustomLine{cl1, cl2, cl3},
			lineGroup:  []*manage.LineGroup{lg1, lg2, lg3},
		},
		{
			name:        "test3_2", // 线路分组
			qname:       qname1,
			initOperate: []*operateEntity{dop1, rop14, rop15, rop16, rop21, rop23, rop34, rop35},
			query: []*queryEntity{
				{ip: testIpMap["js_yd"], results: []string{"999=1", "998=5", "20=69", "16=11", "6=48"}}, // 221.130.0.1
			},
			customLine: []*manage.CustomLine{cl1, cl2, cl3, cl4, cl5},
			lineGroup:  []*manage.LineGroup{lg4, lg5},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			// init geoip
			geoipTest, _ := newGeoIP(cityDBPath)
			if err := geoipTest.Update("IPDB_LINE", "INIT", ipdbLines); err != nil {
				t.Errorf("Error: IPDB INIT FAIL")
			}
			if tt.initOperate != nil {
				for _, v := range tt.initOperate {
					_ = geoipTest.Update(v.resourceType, v.operateType, v.entity)
				}
			}

			for _, cl := range tt.customLine {
				_ = geoipTest.Update("CUSTOM_LINE", "ADD", cl)
			}

			for _, lg := range tt.lineGroup {
				_ = geoipTest.Update("LINE_GROUP", "ADD", lg)
			}

			domain, _ := geoipTest.FindBestZone(tt.qname)

			// test begin
			for _, q := range tt.query {
				results := geoipTest.parse(domain, q.ip)

				if len(results) != len(q.results) {
					t.Errorf("Error: ip= %v, len(results) = %v, len(wantResults) %v", q.ip, len(results), len(q.results))
				}

				for i := range results {
					if results[i] != q.results[i] {
						t.Errorf("Error: ip= %v,  results = %v, wantResults %v", q.ip, results, q.results)
					}
				}
			}
		})
	}
}
