package geoip

import (
	"github.com/coredns/coredns/plugin/manage"
	"gorm.io/driver/mysql"
	"gorm.io/driver/sqlite"
	"gorm.io/gorm"
	"testing"
)

// InitDb 初始化sqlite数据库
func TestInitDb1(t *testing.T) {
	dbFrom, _ := gorm.Open(mysql.Open("pdns:Pass@2020!@tcp(192.168.200.128:3306)/dnsserver?parseTime=true&loc=Local"), &gorm.Config{})
	var ipdbLines []*manage.IpdbLine
	_ = dbFrom.Find(&ipdbLines)

	dbTo, _ := gorm.Open(sqlite.Open("test.db"), &gorm.Config{})
	dbTo.Exec("drop table dns_ipdb_line;")
	_ = dbTo.AutoMigrate(&manage.IpdbLine{})
	dbTo.Save(ipdbLines)
}
