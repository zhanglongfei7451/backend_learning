package geoip

import (
	"fmt"
	"strings"
	"testing"

	"github.com/coredns/caddy"
	"github.com/coredns/coredns/core/dnsserver"
)

var (
	cityDBPath = "./ipdb/ipip_china_cn.ipdb"
)

func TestSetup(t *testing.T) {
	c := caddy.NewTestController("dns", fmt.Sprintf("%s %s", pluginName, cityDBPath))
	plugins := dnsserver.GetConfig(c).Plugin
	if len(plugins) != 0 {
		t.Fatalf("Expected zero plugins after setup, %d found", len(plugins))
	}
	if err := setup(c); err != nil {
		t.Fatalf("Expected no errors, but got: %v", err)
	}
	plugins = dnsserver.GetConfig(c).Plugin
	if len(plugins) != 1 {
		t.Fatalf("Expected one plugin after setup, %d found", len(plugins))
	}
}

func TestGeoIPParse(t *testing.T) {
	c := caddy.NewTestController("dns", fmt.Sprintf("%s %s", pluginName, cityDBPath))
	if err := setup(c); err != nil {
		t.Fatalf("Expected no errors, but got: %v", err)
	}

	tests := []struct {
		name        string
		shouldErr   bool
		config      string
		expectedErr string
	}{
		// Valid
		{"test1", false, fmt.Sprintf("%s %s\n", pluginName, cityDBPath), ""},

		// Invalid
		{"test2", true, pluginName, "Wrong argument count"},
		{"test3", true, fmt.Sprintf("%s %s {\n\tlanguages en fr es zh-CN\n}\n", pluginName, cityDBPath), "unexpected config block"},
		{"test4", true, fmt.Sprintf("%s %s\n%s %s\n", pluginName, cityDBPath, pluginName, cityDBPath), "configuring multiple databases is not supported"},
		{"test5", true, fmt.Sprintf("%s 1 2 3", pluginName), "Wrong argument count"},
		{"test6", true, fmt.Sprintf("%s { }", pluginName), "Error during parsing"},
		{"test7", true, fmt.Sprintf("%s /dbpath { city }", pluginName), "unexpected config block"},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			c := caddy.NewTestController("dns", test.config)
			geoIP, err := geoipParse(c)

			if test.shouldErr && err == nil {
				t.Errorf("xpected error but found none for input %s", test.config)
			}

			if err != nil {
				if !test.shouldErr {
					t.Errorf("expected no error but found one for input %s, got: %v", test.config, err)
				}

				if !strings.Contains(err.Error(), test.expectedErr) {
					t.Errorf("expected error to contain: %v, found error: %v, input: %s", test.expectedErr, err, test.config)
				}
			} else if geoIP.cityReader == nil {
				t.Errorf("after parsing database reader should be initialized")
			}
		})
	}
}
