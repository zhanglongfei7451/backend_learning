package filter

import (
	"fmt"
	"github.com/coredns/coredns/plugin/manage"
	"github.com/fatih/set"
	"k8s.io/apimachinery/pkg/util/rand"
	"testing"
)

func Test_filter_Update(t *testing.T) {
	filter := Filter{zones: set.New(set.NonThreadSafe)}

	type args struct {
		resourceType string
		operateType  string
		content      interface{}
	}
	testAddName := []struct {
		args    args
		wantErr bool
	}{
		{
			args{
				"DOMAIN", "ADD", manage.Domain{DomainName: "a.com"},
			},
			false,
		},
		{
			args{
				"DOMAIN", "ADD", manage.Domain{DomainName: "b.com"},
			},
			false,
		},

		{
			args{
				"DOMAIN", "ADD", manage.Domain{DomainName: "a.com"},
			},
			false,
		},
		{
			args{
				"DOMAIN", "ADD", manage.Domain{DomainName: "c.com"},
			},
			false,
		},
		{
			args{
				"DOMAIN", "ADD", manage.Domain{DomainName: "b.cn"},
			},
			false,
		},
	}

	testDelName := []struct {
		args    args
		wantErr bool
	}{
		{
			args{
				"", "DELETE", manage.Domain{DomainName: "b.com"},
			},
			false,
		},
		{
			args{
				"DOMAIN", "DELETE", manage.Domain{DomainName: "b.com"},
			},
			false,
		},

		{
			args{
				"DOMAIN", "DELETE", manage.Domain{DomainName: "c.com"},
			},
			false,
		},
		{
			args{
				"DOMAIN", "DELETE", manage.Domain{DomainName: "d.com"},
			},
			false,
		},
	}

	for _, tt := range testAddName {
		t.Run("testAddName", func(t *testing.T) {
			if err := filter.Update(tt.args.resourceType, tt.args.operateType, tt.args.content); (err != nil) != tt.wantErr {
				t.Errorf("Update() error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}

	fmt.Println(filter.zones)

	if filter.zones.Size() != 4 {
		t.Errorf("the number of domain name is not expected, expected = %d, real = %d", 4, filter.zones.Size())
	}

	for _, tt := range testDelName {
		t.Run("testDelName", func(t *testing.T) {
			if err := filter.Update(tt.args.resourceType, tt.args.operateType, tt.args.content); (err != nil) != tt.wantErr {
				t.Errorf("Update() error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
	fmt.Println(filter.zones)
	if filter.zones.Size() != 2 {
		t.Errorf("the number of domain name is not expected, expected = %d, real = %d", 3, filter.zones.Size())
	}

}

func BenchmarkAddDomain(b *testing.B) {
	filter := Filter{zones: set.New(set.NonThreadSafe)}
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		filter.addDomain(rand.String(15))
	}
}

func BenchmarkDelDomain(b *testing.B) {
	filter := Filter{zones: set.New(set.NonThreadSafe)}
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		filter.delDomain(rand.String(15))
	}
}
