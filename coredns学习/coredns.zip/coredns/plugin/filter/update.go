package filter

import (
	"github.com/coredns/coredns/plugin/manage"
)

func (filter *Filter) Update(resourceType string, operateType string, content interface{}) error {
	// TODO @陈传运  add DOMAIN PACKAGE_UPDATE, Soa PackageType Instance.PackageType will be changed
	if resourceType != manage.DOMAIN {
		return nil
	}

	domain, ok := content.(manage.Domain)
	if !ok {
		return nil
	}

	switch operateType {
	case manage.ADD:
		return filter.addDomain(domain.DomainName)
	case manage.DELETE:
		return filter.delDomain(domain.DomainName)
	default:
		return nil
	}
}

func (filter *Filter) addDomain(name string) error {
	filter.RWMutex.Lock()
	defer filter.RWMutex.Unlock()
	filter.zones.Add(name)
	return nil
}

func (filter *Filter) delDomain(name string) error {
	filter.RWMutex.Lock()
	defer filter.RWMutex.Unlock()
	filter.zones.Remove(name)
	return nil
}
