package filter

import (
	"context"
	"github.com/coredns/caddy"
	"github.com/coredns/coredns/core/dnsserver"
	"github.com/coredns/coredns/plugin"
	"github.com/coredns/coredns/plugin/metrics"
	clog "github.com/coredns/coredns/plugin/pkg/log"
	"github.com/coredns/coredns/request"
	"github.com/fatih/set"
	"github.com/miekg/dns"
	"github.com/pkg/errors"
	"sync"
)

var log = clog.NewWithPlugin("filter")

type Filter struct {
	Next  plugin.Handler
	zones set.Interface
	sync.RWMutex
}

func init() {
	caddy.RegisterPlugin("filter", caddy.Plugin{
		ServerType: "dns",
		Action:     setup,
	})
}

func setup(c *caddy.Controller) error {
	f := &Filter{zones: set.New(set.NonThreadSafe)}
	dnsserver.GetConfig(c).AddPlugin(func(next plugin.Handler) plugin.Handler {
		f.Next = next
		return f
	})

	return nil
}

// Name implements the Handler interface.
func (filter Filter) Name() string { return "filter" }

// ServeDNS implements the Handler interface.
func (filter Filter) ServeDNS(ctx context.Context, w dns.ResponseWriter, r *dns.Msg) (int, error) {
	state := request.Request{W: w, Req: r}

	filter.RWMutex.RLock()
	defer filter.RWMutex.RUnlock()

	tmpName := state.Name()
	var err error
	for {
		if filter.zones.Has(tmpName) {
			return plugin.NextOrFailure(filter.Name(), filter.Next, ctx, w, r)
		}
		tmpName, err = plugin.Name(tmpName).ParentName()
		if err != nil {
			break
		}
	}
	m := new(dns.Msg)
	m.SetRcode(r, dns.RcodeRefused)
	w.WriteMsg(m)

	RequestsNxDomainTotal.WithLabelValues(metrics.WithServer(ctx)).Inc()
	return dns.RcodeRefused, nil
}

var (
	errNXDomain = errors.New("the query name not created here")
)
