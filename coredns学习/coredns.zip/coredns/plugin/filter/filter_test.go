package filter

import (
	"context"
	"github.com/coredns/coredns/plugin/pkg/dnstest"
	"github.com/coredns/coredns/plugin/test"
	"github.com/fatih/set"
	"github.com/miekg/dns"
	_ "github.com/pkg/errors"
	"testing"
)

func TestFilterServeDNS(t *testing.T) {

	tests := []struct {
		name    string
		qname   string
		want    int
		wantErr bool
	}{
		{
			"reject a.cn",
			"a.cn.",
			dns.RcodeRefused,
			false,
		},
		{
			"accept b.com",
			"www.b.com.",
			dns.RcodeSuccess,
			false,
		},
		{
			"accept b.com",
			"1.a.b.com.",
			dns.RcodeSuccess,
			false,
		},
	}
	filter := Filter{Next: test.NextHandler(dns.RcodeSuccess, nil), zones: set.New(set.NonThreadSafe)}
	filter.addDomain("b.com.")
	filter.addDomain("a.b.com.")
	filter.addDomain("example.com.")
	filter.addDomain("abc.com.")
	filter.addDomain("com.")

	ctx := context.TODO()
	rec := dnstest.NewRecorder(&test.ResponseWriter{})

	for _, tt := range tests {
		req := new(dns.Msg)
		req.SetQuestion(dns.Fqdn(tt.qname), dns.TypeA)
		t.Run(tt.name, func(t *testing.T) {
			got, err := filter.ServeDNS(ctx, rec, req)
			if (err != nil) != tt.wantErr {
				t.Errorf("ServeDNS() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if got != tt.want {
				t.Errorf("ServeDNS() got = %v, want %v", got, tt.want)
			}
		})
	}
}
