# filter

## Name

*filter* - 域名过滤器
TODO 后续可以进一步优化下可过滤的东西，避免和ACL模块的功能冲突

## Description
  过滤当前系统中已用到的域名，对于未被使用的域名直接返回dns.RcodeRefused。该插件需要放到plugin的第一个位置.
该插件继承manager plugin的updater接口。域名增删时会更新要过滤的域名列表


## Examples
开启域名过滤
~~~
. {
    filter
}
~~~