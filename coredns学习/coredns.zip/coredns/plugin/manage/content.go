package manage

import (
	"github.com/miekg/dns"
	"gorm.io/gorm"
	"gorm.io/plugin/soft_delete"
	"strings"
)

// DnsQueue 变更队列实体
type DnsQueue struct {
	SerialNumber int64 `gorm:"primaryKey;autoIncrement"`
	ResourceType string
	OperateType  string
	Content      string
}

// Domain 域名实体
type Domain struct {
	DomainId   string `gorm:"primaryKey;column:id"`
	DomainName string `gorm:"column:name"`
	DbState    string `gorm:"column:state"`
	Ns1        string `gorm:"column:ns1"`
	Ns2        string `gorm:"column:ns2"`
	SoaNs      string `gorm:"column:soa_ns"`
	SoaMailbox string `gorm:"column:soa_mailbox"`
	Deleted    soft_delete.DeletedAt
	Enabled    bool    `gorm:"-"`
	Soa        dns.SOA `gorm:"-"`
}

// Record 解析记录实体
type Record struct {
	DomainName string `gorm:"column:domain_name"`
	RecordId   string `gorm:"primaryKey;column:id"`
	RName      string `gorm:"column:rr"`
	DbType     string `gorm:"column:type"`
	Value      string
	MxPri      uint32
	Ttl        uint32
	LineId     string
	DbState    string `gorm:"column:state"`
	Weight     int16
	Deleted    soft_delete.DeletedAt
	Enabled    bool   `gorm:"-"`
	RType      uint16 `gorm:"-"`
}

// DnssecKey DNSSEC entity
type DnssecKey struct {
	DnssecKeyId string `gorm:"primaryKey;column:id"`
	DomainName  string `gorm:"column:domain_name"`
	Status      string
	ZskKey      string
	ZskPrivate  string
	KskKey      string
	KskPrivate  string

	Ds         string
	KeyTag     uint16 `gorm:"column:ksk_key_tag"`
	Algorithm  uint8
	DigestType uint8
	Digest     string

	KskFlags     uint16 `gorm:"default:257;"`
	ZskFlags     uint16 `gorm:"default:256;"`
	ZskKeyTag    uint16
	KskDnskey    string
	ZskDnskey    string
	KeyAlgorithm uint8
	Protocol     uint8 `gorm:"default:3;"`

	Deleted soft_delete.DeletedAt
}

type CustomLine struct {
	LineId  string `gorm:"primaryKey;column:id"`
	DbIps   string `gorm:"column:ips"`
	Deleted soft_delete.DeletedAt
	Ips     []string `gorm:"-"`
}

type LineGroup struct {
	LineId    string `gorm:"primaryKey;column:id"`
	DbLineIds string `gorm:"column:lines"`
	Deleted   soft_delete.DeletedAt
	LineIds   []string `gorm:"-"`
}

type IpdbLine struct {
	LineType string
	Key      string
	Value    string
}

type Ptr struct {
	Id        string `gorm:"primaryKey;"`
	Ip        string
	Ttl       uint32
	Host      string
	Enabled   bool   `gorm:"-"`
	DbState   string `gorm:"column:state"`
	PtrZoneId string `gorm:"column:ptr_zone_id"`
	Deleted   soft_delete.DeletedAt
}

type PtrZone struct {
	Id      string `gorm:"primaryKey;"`
	Cidr    string
	Deleted soft_delete.DeletedAt
}

func (domain *Domain) AfterFind(*gorm.DB) (err error) {
	domain.DomainName = strings.ToLower(dns.Fqdn(domain.DomainName))
	if domain.DbState == DOMAIN_ENABLED {
		domain.Enabled = true
	} else {
		domain.Enabled = false
	}
	return
}

func (record *Record) AfterFind(*gorm.DB) (err error) {
	record.DomainName = dns.Fqdn(record.DomainName)
	record.DomainName = strings.ToLower(record.DomainName)
	record.RName = strings.ToLower(record.RName)
	record.RType = RecordTypeMap[record.DbType]

	// record value 去除前后空格
	record.Value = strings.TrimSpace(record.Value)

	if record.DbState == RECORD_ENABLED {
		record.Enabled = true
	} else {
		record.Enabled = false
	}
	// SRV 中的 value = 0 5 8080 sipserver.dnspod.cn 自行处理
	if record.RType == dns.TypeNS || record.RType == dns.TypeCNAME || record.RType == dns.TypeMX || record.RType == dns.TypePTR {
		record.Value = strings.ToLower(record.Value)
		record.Value = dns.Fqdn(record.Value)
	}
	return
}

func (dnssecKey *DnssecKey) AfterFind(*gorm.DB) (err error) {
	dnssecKey.DomainName = dns.Fqdn(dnssecKey.DomainName)
	dnssecKey.DomainName = strings.ToLower(dnssecKey.DomainName)
	return
}

func (c *CustomLine) AfterFind(*gorm.DB) (err error) {
	c.Ips = strings.Split(c.DbIps, ";")
	return
}

func (l *LineGroup) AfterFind(*gorm.DB) (err error) {
	l.LineIds = strings.Split(l.DbLineIds, ",")
	return
}

func (ptr *Ptr) AfterFind(*gorm.DB) (err error) {
	ptr.Host = dns.Fqdn(ptr.Host)
	if ptr.DbState == PTR_DISABLED {
		ptr.Enabled = false
	} else {
		//默认enabled
		ptr.Enabled = true
	}
	return
}

func (DnsQueue) TableName() string {
	return TableDnsQueue
}
func (Domain) TableName() string {
	return TableDomain
}
func (Record) TableName() string {
	return TableRecord
}

func (DnssecKey) TableName() string {
	return TableDnssec
}

func (CustomLine) TableName() string {
	return TableCustomLine
}

func (LineGroup) TableName() string {
	return TableLineGroup
}

func (IpdbLine) TableName() string {
	return TableIpdbLine
}

func (Ptr) TableName() string {
	return TablePtr
}

func (PtrZone) TableName() string {
	return TablePtrZone
}

// table name
const (
	TableDnsQueue   = "dns_queue"
	TableDomain     = "dns_domain"
	TableRecord     = "dns_record"
	TableDnssec     = "dns_dnssec_key"
	TableCustomLine = "dns_custom_line"
	TableLineGroup  = "dns_custom_line_group"
	TableIpdbLine   = "dns_ipdb_line"
	TablePtr        = "dns_ptr"
	TablePtrZone    = "dns_ptr_zone"
)

// resource type
const (
	DOMAIN      = "DOMAIN"
	RECORD      = "RECORD"
	DNSSEC      = "DNSSEC"
	CUSTOM_LINE = "CUSTOM_LINE"
	LINE_GROUP  = "LINE_GROUP"
	IPDB_LINE   = "IPDB_LINE"
	PTR         = "PTR"
	PTRZONE     = "PTRZONE"
)

// operation type
const (
	ADD            = "ADD"
	DELETE         = "DELETE"
	UPDATE         = "UPDATE"
	ENABLE         = "ENABLE"
	DISABLE        = "DISABLE"
	INIT           = "INIT"
	PACKAGE_UPDATE = "PACKAGE_UPDATE"
)

// Sql Key
const (
	SqlMaxSerialNumber = "getMaxSerialNumber"
)

// Domain Record state
const (
	DOMAIN_ENABLED = "ENABLED"
	RECORD_ENABLED = "ENABLED"
	PTR_DISABLED   = "DISABLED"
)

var RecordTypeMap = map[string]uint16{
	"A":     dns.TypeA,
	"NS":    dns.TypeNS,
	"CNAME": dns.TypeCNAME,
	"SOA":   dns.TypeSOA,
	"PTR":   dns.TypePTR,
	"MX":    dns.TypeMX,
	"TXT":   dns.TypeTXT,
	"AAAA":  dns.TypeAAAA,
	"SRV":   dns.TypeSRV,
	"SPF":   dns.TypeSPF,
	"CAA":   dns.TypeCAA,
}
