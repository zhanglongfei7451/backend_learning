package manage

import (
	"errors"
	"github.com/coredns/caddy"
	"github.com/coredns/coredns/core/dnsserver"
	"github.com/coredns/coredns/plugin"
	clog "github.com/coredns/coredns/plugin/pkg/log"
	"github.com/miekg/dns"
	"regexp"
	"strconv"
	"strings"
	"time"
)

var log = clog.NewWithPlugin("manage")

const (
	defaultSerialNumber       = -1
	defaultMaxLifeTime        = 30 * time.Minute
	defaultMaxOpenConnections = 30
	defaultMaxIdleConnections = 30
	defaultUpdateInterval     = 1 * time.Minute
)

const (
	soaName       = ""
	soaTtl        = 3600  //1hour
	soaExpire     = 86400 //1day
	soaRetry      = 3600  //1hour
	soaRefresh    = 86400 //1day
	soaSerial     = 1
	soaDefaultNs1 = "ns1.cmedns.com."
	soaDefaultNs2 = "ns2.cmedns.com."
	pluginName    = "manage"
)

func init() { plugin.Register(pluginName, setup) }

func setup(c *caddy.Controller) error {
	manage, err := manageParse(c)
	if err != nil {
		return plugin.Error(pluginName, err)
	}

	executeChan := make(chan bool)

	c.OnStartup(func() error {
		plugins := dnsserver.GetConfig(c).Handlers()
		for _, p := range plugins {
			if met, ok := p.(Updater); ok {
				manage.Updaters = append(manage.Updaters, met)
			}
		}

		err := manage.setDb()
		if err != nil {
			return err
		}

		err = manage.initPlugin()
		if err != nil {
			return err
		}
		return manage.startTicker(executeChan)
	})

	c.OnShutdown(func() error {
		sqlDb, _ := manage.Db.DB()
		err = sqlDb.Close()
		if err != nil {
			log.Errorf("Fail to close database connection. ErrorInfo: %v", err)
		}
		return manage.stopTicker(executeChan)
	})

	// Don't need to AddPlugin, as manage is not *really* a plugin just a managers

	return nil
}

func manageParse(c *caddy.Controller) (*Manage, error) {
	manage := &Manage{SerialNumber: defaultSerialNumber}
	initSoaAndNs(manage)

	c.Next()
	var err error
	if c.NextBlock() {
		for {
			switch c.Val() {
			case "mysql":
				err = mysqlParse(c, manage)
			case "config":
				err = configParse(c, manage)
			case "ns":
				err = nsParse(c, manage)
			case "sql":
				err = sqlParse(c, manage)
			default:
				if c.Val() != "}" {
					err = c.ArgErr()
				}
			}
			if err != nil {
				return &Manage{}, err
			}
			c.Next()
			if c.Val() == "}" {
				break
			}
		}
	}
	return manage, nil
}

func mysqlParse(c *caddy.Controller, manage *Manage) error {
	manage.Mysql.MaxLifetime = defaultMaxLifeTime
	manage.Mysql.MaxOpenConnections = defaultMaxOpenConnections
	manage.Mysql.MaxIdleConnections = defaultMaxIdleConnections
	c.Next()
	if c.NextBlock() {
		for {
			switch c.Val() {
			case "dsn":
				if !c.NextArg() {
					return c.ArgErr()
				}
				manage.Mysql.Dsn = parseDsn(c.Val())
			case "max_lifetime":
				if !c.NextArg() {
					return c.ArgErr()
				}
				val, err := time.ParseDuration(c.Val())
				if err == nil {
					manage.Mysql.MaxLifetime = val
				}
			case "max_open_connections":
				if !c.NextArg() {
					return c.ArgErr()
				}
				val, err := strconv.Atoi(c.Val())
				if err == nil {
					manage.Mysql.MaxOpenConnections = val
				}
			case "max_idle_connections":
				if !c.NextArg() {
					return c.ArgErr()
				}
				val, err := strconv.Atoi(c.Val())
				if err != nil {
					manage.Mysql.MaxIdleConnections = val
				}
			default:
				log.Warningf("mysql 子配置未读取, 配置值：%s", c.Val())
			}
			c.Next()
			if c.Val() == "}" {
				break
			}
		}
	}
	return nil
}

//支持dsn中的password加密 or 不加密 or 不配置password
func parseDsn(dsn string) string {
	dsnPasswdReg := regexp.MustCompile(`:.*@`)
	tmp := dsnPasswdReg.FindAllStringSubmatch(dsn, -1)
	if len(tmp) <= 0 {
		return dsn
	}
	dsnPasswd := strings.TrimSuffix(strings.TrimPrefix(tmp[0][0], ":"), "@")
	decryptPasswd, err := DecryptByAes(dsnPasswd)

	if err != nil {
		log.Warning("mysql password maybe not encrypted or not encrypted by right algorithm")
		return dsn
	}
	return strings.Replace(dsn, dsnPasswd, string(decryptPasswd), 1)
}

func configParse(c *caddy.Controller, manage *Manage) error {
	c.Next()
	if c.NextBlock() {
		for {
			switch c.Val() {
			case "update_interval":
				if !c.NextArg() {
					return c.ArgErr()
				}
				val, err := time.ParseDuration(c.Val())
				if err != nil {
					val = defaultUpdateInterval
				}
				manage.UpdateInterval = val
			default:
				log.Warningf("config 子配置未读取, 配置值：%s", c.Val())
			}
			c.Next()
			if c.Val() == "}" {
				break
			}
		}
	}
	return nil
}

func nsParse(c *caddy.Controller, manage *Manage) error {
	manage.Ns = make(map[string][]string)
	c.Next()
	if c.NextBlock() {
		for {
			packageType := c.Val()
			ns := c.RemainingArgs()
			manage.Ns[packageType] = ns
			c.Next()
			if c.Val() == "}" {
				break
			}
		}
	}
	return nil
}

func sqlParse(c *caddy.Controller, manage *Manage) error {
	manage.sql = make(map[string]string)
	c.Next()
	if c.NextBlock() {
		for {
			key := c.Val()
			if !c.NextArg() {
				return c.ArgErr()
			}
			manage.sql[key] = c.Val()
			c.Next()
			if c.Val() == "}" {
				break
			}
		}
	}
	if _, isOk := manage.sql[SqlMaxSerialNumber]; !isOk {
		return errors.New("Sql Key Missing")
	}
	return nil
}

func initSoaAndNs(manage *Manage) {

	soa := &dns.SOA{Hdr: dns.RR_Header{Name: soaName, Rrtype: dns.TypeSOA, Class: dns.ClassINET, Ttl: soaTtl},
		Minttl:  soaTtl,
		Expire:  soaExpire,
		Retry:   soaRetry,
		Refresh: soaRefresh,
		Serial:  soaSerial,
		Mbox:    soaDefaultNs2,
		Ns:      soaDefaultNs1,
	}
	manage.soa = *soa

	defaultNsRecord := &Record{
		RecordId: "",
		RName:    "@",
		RType:    dns.TypeNS,
		Value:    soaDefaultNs1,
		Ttl:      3600,
		Enabled:  true,
		Weight:   1,
		LineId:   "0",
	}
	manage.defaultNsRecord = *defaultNsRecord

}
