package manage

import (
	"errors"
	"strings"
)

// execute read dns_queue and send to each plugin for update
func (manage *Manage) execute() {

	var (
		serialStart int64
		serialEnd   int64
		err         error
		db          = manage.Db
	)

	if serialEnd, err = manage.getSerialNumber(); err != nil {
		return
	}

	manage.rw.Lock()
	defer manage.rw.Unlock()

	if serialStart = manage.SerialNumber; serialStart < 0 || serialStart >= serialEnd {
		return
	}

	var queues []DnsQueue
	if err = db.Where("serial_number BETWEEN ? AND ?", serialStart+1, serialEnd).Find(&queues).Error; err != nil {
		log.Errorf("Fail to Query Queue. serialStart: %d. serialEnd %d. ErrorInfo: %v", serialStart, serialEnd, err)
		return
	}

	for _, queue := range queues {

		switch queue.ResourceType + queue.OperateType {
		case DOMAIN + ADD, DOMAIN + PACKAGE_UPDATE:
			domain, err := manage.getDomainById(queue.Content)
			if err != nil {
				continue
			}
			manage.changeZonesWithNs([]*Domain{domain}, queue.OperateType)
		case DOMAIN + DELETE, DOMAIN + ENABLE, DOMAIN + DISABLE:
			domain, err := manage.getDomainById(queue.Content)
			if err != nil {
				continue
			}
			manage.updateZones([]*Domain{domain}, queue.OperateType)

		case DNSSEC + ADD, DNSSEC + DELETE:
			{
				dnssecKey, err := manage.getDnssecKeyById(queue.Content)
				if err != nil {
					continue
				}
				manage.updateDnssec([]*DnssecKey{dnssecKey}, queue.OperateType)
			}
		case RECORD + ADD, RECORD + DELETE, RECORD + ENABLE, RECORD + DISABLE:
			record, err := manage.getRecordById(queue.Content)
			if err != nil {
				continue
			}
			manage.updateRecords([]*Record{record}, queue.OperateType)
		case RECORD + UPDATE:
			recordId, oldRr := manage.SplitRecordRr(queue.Content)
			record, err := manage.getRecordById(recordId)
			if err != nil {
				continue
			}
			oldRecord := &Record{DomainName: record.DomainName, RecordId: recordId, RName: oldRr}
			if oldRr == "" { // 适配未加old rr的情况
				oldRecord.RName = record.RName
			}
			manage.updateRecords([]*Record{oldRecord}, DELETE)
			manage.updateRecords([]*Record{record}, ADD)
		case CUSTOM_LINE + ADD, CUSTOM_LINE + UPDATE, CUSTOM_LINE + DELETE:
			customLine, err := manage.getCustomLineById(queue.Content)
			if err != nil {
				continue
			}
			manage.updateCustomLine([]*CustomLine{customLine}, queue.OperateType)
		case LINE_GROUP + ADD, LINE_GROUP + UPDATE, LINE_GROUP + DELETE:
			lineGroup, err := manage.getLineGroupById(queue.Content)
			if err != nil {
				continue
			}
			manage.updateLineGroup([]*LineGroup{lineGroup}, queue.OperateType)
		case PTR + ADD, PTR + DELETE, PTR + ENABLE, PTR + DISABLE:
			ptr, err := manage.getPtrById(queue.Content)
			if err != nil {
				continue
			}
			manage.updatePtr([]*Ptr{ptr}, queue.OperateType)
		case PTR + UPDATE:
			id, oldHost := manage.SplitRecordRr(queue.Content)
			ptr, err := manage.getPtrById(id)
			if err != nil {
				continue
			}
			oldPtr := &Ptr{
				Id:        id,
				Ip:        ptr.Ip,
				Host:      oldHost,
				PtrZoneId: ptr.PtrZoneId,
				DbState:   ptr.DbState,
				Enabled:   ptr.Enabled,
				Ttl:       ptr.Ttl,
			}
			if oldHost == "" {
				oldPtr.Host = ptr.Host
			}
			manage.updatePtr([]*Ptr{oldPtr}, DELETE)
			manage.updatePtr([]*Ptr{ptr}, ADD)
		case PTRZONE + ADD, PTRZONE + DELETE:
			ptrZone, err := manage.getPtrZoneById(queue.Content)
			if err != nil {
				continue
			}
			manage.updatePtrZone([]*PtrZone{ptrZone}, queue.OperateType)
		default:
			log.Errorf("Fail to handle. resourceType: %s, operateType: %s .", queue.ResourceType, queue.OperateType)
		}
	}

	manage.SerialNumber = serialEnd
}

// SplitRecordRr return recordId, old rr
func (manage *Manage) SplitRecordRr(str string) (string, string) {
	parts := strings.Split(str, "+")
	if len(parts) < 2 {
		return str, ""
	}
	return parts[0], strings.TrimSpace(strings.ToLower(parts[1])) // old rr 去空格，转小写
}

func (manage *Manage) getRecordById(id string) (*Record, error) {
	var record []*Record
	if err := manage.Db.Unscoped().Find(&record, "id = ?", id).Error; err != nil {
		log.Errorf("Fail to Get Record By Id. Id: %s. ErrorInfo: %v", id, err)
		return nil, err
	}
	if len(record) < 1 {
		err := errors.New("record item not exist")
		log.Errorf("Fail to Get Record By Id. Id: %s. ErrorInfo: %v", id, err)
		return nil, err
	}
	return record[0], nil
}

func (manage *Manage) getDomainById(id string) (*Domain, error) {
	var zone []*Domain
	if err := manage.Db.Unscoped().Find(&zone, "id = ?", id).Error; err != nil {
		log.Errorf("Fail to Get Domain By Id. Id: %s. ErrorInfo: %v", id, err)
		return nil, err
	}
	if len(zone) < 1 {
		err := errors.New("zone item not exist")
		log.Errorf("Fail to Get Domain By Id. Id: %s. ErrorInfo: %v", id, err)
		return nil, err
	}

	manage.fillSoa(zone[0])
	return zone[0], nil
}

func (manage *Manage) getDnssecKeyById(id string) (*DnssecKey, error) {
	var dnssecKey []*DnssecKey
	if err := manage.Db.Unscoped().Find(&dnssecKey, "id = ?", id).Error; err != nil {
		log.Errorf("Fail to Get DnssecKey By Id. Id: %s. ErrorInfo: %v", id, err)
		return nil, err
	}
	if len(dnssecKey) < 1 {
		err := errors.New("DnssecKey item not exist")
		log.Errorf("Fail to Get DnssecKey By Id. Id: %s. ErrorInfo: %v", id, err)
		return nil, err
	}

	return dnssecKey[0], nil
}

func (manage *Manage) getCustomLineById(id string) (*CustomLine, error) {
	var entity []*CustomLine
	if err := manage.Db.Unscoped().Find(&entity, "id = ?", id).Error; err != nil {
		log.Errorf("Fail to Get CustomLine By Id. Id: %s. ErrorInfo: %v", id, err)
		return nil, err
	}
	if len(entity) < 1 {
		err := errors.New("custom item not exist")
		log.Errorf("Fail to Get CustomLine By Id. Id: %s. ErrorInfo: %v", id, err)
		return nil, err
	}
	return entity[0], nil
}

func (manage *Manage) getLineGroupById(id string) (*LineGroup, error) {
	var entity []*LineGroup
	if err := manage.Db.Unscoped().Find(&entity, "id = ?", id).Error; err != nil {
		log.Errorf("Fail to Get LineGroup By Id. Id: %s. ErrorInfo: %v", id, err)
		return nil, err
	}
	if len(entity) < 1 {
		err := errors.New("custom item not exist")
		log.Errorf("Fail to Get LineGroup By Id. Id: %s. ErrorInfo: %v", id, err)
		return nil, err
	}
	return entity[0], nil
}

func (manage *Manage) getPtrById(id string) (*Ptr, error) {
	var entity []*Ptr
	if err := manage.Db.Unscoped().Find(&entity, "id = ?", id).Error; err != nil {
		log.Errorf("Fail to Get Ptr By Id. Id: %s. ErrorInfo: %v", id, err)
		return nil, err
	}
	if len(entity) < 1 {
		err := errors.New("custom item not exist")
		log.Errorf("Fail to Get Ptr By Id. Id: %s. ErrorInfo: %v", id, err)
		return nil, err
	}
	return entity[0], nil
}

func (manage *Manage) getPtrZoneById(id string) (*PtrZone, error) {
	var entity []*PtrZone
	if err := manage.Db.Unscoped().Find(&entity, "id = ?", id).Error; err != nil {
		log.Errorf("Fail to Get PtrZone By Id. Id: %s. ErrorInfo: %v", id, err)
		return nil, err
	}
	if len(entity) < 1 {
		err := errors.New("custom item not exist")
		log.Errorf("Fail to Get PtrZone By Id. Id: %s. ErrorInfo: %v", id, err)
		return nil, err
	}
	return entity[0], nil
}
