package manage

type Updater interface {

	// Update resourceType(operateType) :
	//   DOMAIN(ADD/DELETE/ENABLE/DISABLE/PACKAGE_UPDATE)
	//   RECORD(ADD/DELETE/ENABLE/DISABLE)
	//   DNSSEC(ADD/DELETE)
	//   ACL(ADD/DELETE/UPDATE)
	//   CUSTOM_LINE(ADD/UPDATE/DELETE) if line is in used, can not be deleted
	//   LINE_GROUP(ADD/UPDATE/DELETE) if line is in used, can not be deleted
	//   IPDB_LINE(INIT)
	//   PTR(ADD/UPDATE/DELETE/ENABLE/DISABLE)
	Update(resourceType string, operateType string, content interface{}) error
}
