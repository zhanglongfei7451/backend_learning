# manage

## Name

*manage* - dns信息管理器.

## Description

该插件使用Mysql作为dns的可持久化存储后端。服务启动/重启时，将通知其它插件做dns的初始化操作，初始化时传入dns相关信息。此外，该插件每隔 一段时间读取dns_queue表获取更新信息，并通知各个插件做更新操作。每个dns
server通过serialNumber来保持一致性。

若需被manage插件通知，实现以下接口：
~~~
type Updater interface {
	Update(resourceType string, operateType string, content interface{}) error
}
~~~

## Syntax

~~~
manage {
     config {
       update_interval DURATION
     }
     mysql {
      dsn DSN
      [max_lifetime MAX_LIFETIME]
      [max_open_connections MAX_OPEN_CONNECTIONS]
      [max_idle_connections MAX_IDLE_CONNECTIONS]
     }
     ns {
       packageType [NS_LIST]
     }
     sql {
       getMaxSerialNumber "select max(serial_number) as serial_number from dns_queue;"
     }
}
~~~

**config** manage插件的通用配置

* `update_interval` coredns扫描数据库的频率，默认1分钟扫描一次。每次扫描dns_queue表, 根据serialNumber判断本服务器数据版本是否最新，
  若不是，获取更新的数据通知到各个插件。值为“0”表示不扫描更改。“30s”表示每30s检查一次数据库并通知更新。

**mysql** 数据库相关配置

* `dsn` 根据https://github.com/go-sql-driver/mysql示例填写。您可以$ENV_NAME将该值替换为环境变量。
* `max_lifetime` SQL连接可重用的最大时间长度。默认为 30 分钟。
* `max_open_connections` 打开的最大连接数。默认值为 30 。
* `max_idle_connections` 最大空闲连接数。默认值为 30 。

**ns** 新域名的ns记录

* `packageType` 参考配置下发服务云解析中的设计。
* `NS_LIST` 套餐对应的NS列表。参考https://ecloud.10086.cn/op-help-center/doc/article/42308设置。

**sql** 数据库查询语句

* `getMaxSerialNumber` 获取当前数据的版本号

## Examples

服务启动后，无需根据版本更新， update_interval设置为0
~~~
     config {
       update_interval 0
     }
~~~
若需设置检查的间隔时间，单位可使用 "ns", "us" (or "µs"), "ms", "s", "m", "h". 例如: 服务启动后，每隔2分钟检查一下版本是否最新
~~~
     config {
       update_interval 2m
     }
~~~
数据库设置样例
~~~
     mysql {
      dsn coredns:Pass@2020!@tcp(100.71.9.148:3306)/bc_dns1
      max_lifetime 20m
      max_open_connections 10
      max_idle_connections 20
     }
~~~
ns参考https://ecloud.10086.cn/op-help-center/doc/article/42308设置。样例：
~~~
     ns {
       FREE ns1.cmedns.com ns2.cmedns.com
       PERSONAL ns3.dns.cmecloud.cn ns4.dns.cmecloud.cn
       STANDARD vip1.cmedns.com vip2.cmedns.com
       PREMIUM vip3.cmedns.com vip4.cmedns.com
       ULTIMATE vip5.cmedns.com vip6.cmedns.com
     }
~~~
sql配置一般不建议修改
~~~
     sql {
       getMaxSerialNumber "select max(serial_number) as serial_number from dns_queue;"
     }
~~~
config、mysql、ns等大范围配置，顺序可按需修改