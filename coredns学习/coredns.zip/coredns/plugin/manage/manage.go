package manage

import (
	"database/sql"
	"github.com/coredns/coredns/plugin"
	"github.com/miekg/dns"
	"gorm.io/driver/mysql"
	"gorm.io/gorm"
	"strconv"
	"sync"
	"time"
)

type (
	Manage struct {
		Next           plugin.Handler
		UpdateInterval time.Duration
		rw             sync.RWMutex
		SerialNumber   int64
		Updaters       []Updater
		Mysql
		Ns              map[string][]string
		sql             map[string]string
		soa             dns.SOA
		defaultNsRecord Record
		Db              *gorm.DB
	}

	Mysql struct {
		Dsn                string
		MaxLifetime        time.Duration
		MaxOpenConnections int
		MaxIdleConnections int
	}
)

func (manage *Manage) initPlugin() error {

	var (
		zones       []*Domain
		records     []*Record
		dnssecKeys  []*DnssecKey
		customLines []*CustomLine
		lineGroups  []*LineGroup
		ipdbLines   []*IpdbLine
		ptrZones    []*PtrZone
		ptrs        []*Ptr
		db          = manage.Db
	)

	//域名、解析记录、queue setup
	serialNumber, err := manage.getSerialNumber()
	if err != nil {
		return err
	}

	if err = db.Find(&zones).Error; err != nil {
		return err
	}
	if err = db.Find(&records).Error; err != nil {
		return err
	}
	manage.changeZonesWithNs(zones, ADD)
	manage.updateRecords(records, ADD)

	if err = db.Find(&dnssecKeys).Error; err != nil {
		return err
	}
	manage.updateDnssec(dnssecKeys, ADD)

	// 线路相关setup
	if err = db.Find(&customLines).Error; err != nil {
		return err
	}
	manage.updateCustomLine(customLines, ADD)
	if err = db.Find(&lineGroups).Error; err != nil {
		return err
	}
	manage.updateLineGroup(lineGroups, ADD)
	if err = db.Find(&ipdbLines).Error; err != nil {
		return err
	}
	manage.initIpdbLine(ipdbLines)

	// ptr 相关setup
	if err = db.Find(&ptrZones).Error; err != nil {
		return err
	}
	manage.updatePtrZone(ptrZones, ADD)
	if err = db.Find(&ptrs).Error; err != nil {
		return err
	}
	manage.updatePtr(ptrs, ADD)

	manage.rw.Lock()
	manage.SerialNumber = serialNumber
	manage.rw.Unlock()
	return nil
}

// getSerialNumber get maxSerialNumber from database
func (manage *Manage) getSerialNumber() (int64, error) {
	var (
		sqlStr       = manage.sql[SqlMaxSerialNumber]
		serialNumber sql.NullInt64
		err          error
	)
	if err = manage.Db.Raw(sqlStr).Scan(&serialNumber).Error; err != nil {
		log.Errorf("Fail to Get MaxSerialNumber. ErrorInfo: %v", err)
		return -1, err
	}
	return serialNumber.Int64, err // if queue do not have record, it will return 0,nil
}

// changeZonesWithNs info plugin to add zone
func (manage *Manage) changeZonesWithNs(zones []*Domain, operateType string) {

	for _, zone := range zones {
		nsList := manage.getNsList(zone)
		manage.fillSoa(zone)
		zone.DomainName = dns.Fqdn(zone.DomainName)

		for _, updater := range manage.Updaters {
			err := updater.Update(DOMAIN, operateType, zone)
			if err != nil {
				log.Errorf("Fail to %s Domain. DomainName: %s. ErrorInfo: %v", operateType, zone.DomainName, err)
				continue
			}

			if operateType == "PACKAGE_UPDATE" { // 新增前先删
				nsRecord := manage.defaultNsRecord
				nsRecord.DomainName = zone.DomainName
				if err := updater.Update(RECORD, DELETE, &nsRecord); err != nil {
					log.Errorf("Fail to DELETE Record. RecordId: %s. ErrorInfo: %v", nsRecord.RecordId, err)
					continue
				}
			}

			for i, ns := range nsList {
				record := manage.defaultNsRecord
				record.DomainName = zone.DomainName
				record.RecordId = strconv.Itoa(0 - i)
				record.Value = ns
				err := updater.Update(RECORD, ADD, &record)
				if err != nil {
					log.Errorf("Fail to ADD Record. RecordId: %s. ErrorInfo: %v", record.RecordId, err)
				}
			}
		}
	}
}

// getDomainNsList getNsList from zone
func (manage *Manage) getNsList(zone *Domain) []string {
	return []string{zone.Ns1, zone.Ns2}
}

// fillSoa fill zone.Soa info
func (manage *Manage) fillSoa(zone *Domain) {
	zone.Soa = manage.soa
	zone.Soa.Hdr.Name = zone.DomainName
	zone.Soa.Ns = zone.SoaNs
	zone.Soa.Mbox = zone.SoaMailbox
}

// updateZones info plugin to update zone
// operateType DELETE ENABLE DISABLE PACKAGE_UPDATE
func (manage *Manage) updateZones(zones []*Domain, operateType string) {
	if len(zones) <= 0 {
		return
	}
	for _, zone := range zones {
		for _, updater := range manage.Updaters {
			err := updater.Update(DOMAIN, operateType, zone)
			if err != nil {
				log.Errorf("Fail to Update Domain. DomainName: %s. ErrorInfo: %v", zone.DomainName, err)
			}
		}
	}
}

// updateDnssec info plugin to update Dnssec
// operateType ADD DELETE
func (manage *Manage) updateDnssec(dnssecKeys []*DnssecKey, operateType string) {
	if len(dnssecKeys) <= 0 {
		return
	}
	for _, dnssecKey := range dnssecKeys {
		for _, updater := range manage.Updaters {
			err := updater.Update(DNSSEC, operateType, dnssecKey)
			if err != nil {
				log.Errorf("Fail to Update Dnssec. DnssecKeyId: %s. ErrorInfo: %v", dnssecKey.DnssecKeyId, err)
			}
		}
	}
}

// updateRecords info plugin to update records
// operateType ADD UPDATE DELETE ENABLE DISABLE
func (manage *Manage) updateRecords(records []*Record, operateType string) {
	if len(records) <= 0 {
		return
	}
	for _, record := range records {
		for _, updater := range manage.Updaters {
			err := updater.Update(RECORD, operateType, record)
			if err != nil {
				log.Errorf("Fail to Update Record. RecordId: %s. ErrorInfo: %v", record.RecordId, err)
			}
		}
	}
}

// updateCustomLine info plugin to update customLines
// operateType ADD UPDATE DELETE
func (manage *Manage) updateCustomLine(lines []*CustomLine, operateType string) {
	if len(lines) <= 0 {
		return
	}
	for _, l := range lines {
		for _, updater := range manage.Updaters {
			err := updater.Update(CUSTOM_LINE, operateType, l)
			if err != nil {
				log.Errorf("Fail to Update CustomLine. LineId: %s. ErrorInfo: %v", l.LineId, err)
			}
		}
	}
}

// updateLineGroup info plugin to update lineGroups
// operateType ADD UPDATE DELETE
func (manage *Manage) updateLineGroup(lines []*LineGroup, operateType string) {
	if len(lines) <= 0 {
		return
	}
	for _, l := range lines {
		for _, updater := range manage.Updaters {
			err := updater.Update(LINE_GROUP, operateType, l)
			if err != nil {
				log.Errorf("Fail to Update LineGroup. LineId: %s. ErrorInfo: %v", l.LineId, err)
			}
		}
	}
}

// initIpdbLine info plugin to update IpdbLine
// operateType INIT
func (manage *Manage) initIpdbLine(ipdbLines []*IpdbLine) {
	if len(ipdbLines) <= 0 {
		return
	}
	for _, updater := range manage.Updaters {
		err := updater.Update(IPDB_LINE, INIT, ipdbLines)
		if err != nil {
			log.Errorf("Fail to Update LineGroup. ErrorInfo: %v", err)
		}
	}
}

// updatePtrZone info plugin to update ptrZones
// operateType ADD DELETE
func (manage *Manage) updatePtrZone(zones []*PtrZone, operateType string) {
	if len(zones) <= 0 {
		return
	}
	for _, z := range zones {
		for _, updater := range manage.Updaters {
			err := updater.Update(PTRZONE, operateType, z)
			if err != nil {
				log.Errorf("Fail to Update PtrZone. id :%s. cidr: %s. ErrorInfo: %v", z.Id, z.Cidr, err)
			}
		}
	}
}

// updatePtr info plugin to update ptr
// operateType ADD UPDATE DELETE
func (manage *Manage) updatePtr(ptrs []*Ptr, operateType string) {
	if len(ptrs) <= 0 {
		return
	}
	for _, p := range ptrs {
		for _, updater := range manage.Updaters {
			err := updater.Update(PTR, operateType, p)
			if err != nil {
				log.Errorf("Fail to Update Ptr. id: %s. ip: %s. operateType:%s. PtrZoneId:%s. ErrorInfo: %v", p.Id, p.Ip, operateType, p.PtrZoneId, err)
			}
		}
	}
}

func (manage *Manage) startTicker(executeChan chan bool) error {
	if manage.UpdateInterval == 0 {
		return nil
	}
	go func() {
		ticker := time.NewTicker(manage.UpdateInterval)
		for {
			select {
			case <-executeChan:
				return
			case <-ticker.C:
				manage.execute()
			}
		}
	}()
	return nil
}

func (manage *Manage) stopTicker(executeChan chan bool) error {
	close(executeChan)
	return nil
}

func (manage *Manage) setDb() error {

	db, err := gorm.Open(mysql.Open(manage.Mysql.Dsn), &gorm.Config{
		PrepareStmt:            false,
		SkipDefaultTransaction: true, // 暂无写入操作, 禁用后提升大约30%+性能提升
	})

	if err != nil {
		log.Errorf("Fail to connect database. ErrorInfo: %v", err)
		return err
	}

	sqlDB, err := db.DB()
	if sqlDB == nil {
		log.Errorf("Fail to connect database. ErrorInfo: %v", err)
		return err
	}

	sqlDB.SetMaxIdleConns(manage.Mysql.MaxOpenConnections)
	sqlDB.SetMaxOpenConns(manage.Mysql.MaxOpenConnections)
	sqlDB.SetConnMaxLifetime(manage.Mysql.MaxLifetime)

	manage.Db = db
	return nil
}

func (manage *Manage) InitIresolverForTest() error {
	soa := &dns.SOA{Hdr: dns.RR_Header{Name: soaName, Rrtype: dns.TypeSOA, Class: dns.ClassINET, Ttl: soaTtl},
		Minttl:  soaTtl,
		Expire:  soaExpire,
		Retry:   soaRetry,
		Refresh: soaRefresh,
		Serial:  soaSerial,
		Mbox:    soaDefaultNs2,
		Ns:      soaDefaultNs1,
	}
	defaultNsRecord := &Record{
		RecordId: "",
		RName:    "@",
		RType:    dns.TypeNS,
		Value:    soaDefaultNs1,
		Ttl:      3600,
		Enabled:  true,
		LineId:   "0",
		Weight:   1,
	}
	manage.soa = *soa
	manage.defaultNsRecord = *defaultNsRecord
	var (
		zones   []*Domain
		records []*Record
		db      = manage.Db
	)
	if err := db.Find(&zones).Error; err != nil {
		return err
	}
	if err := db.Find(&records).Error; err != nil {
		return err
	}
	manage.changeZonesWithNs(zones, ADD)
	manage.updateRecords(records, ADD)
	return nil
}

func (manage *Manage) InitPtrForTest() error {
	var (
		zones []*PtrZone
		ptrs  []*Ptr
		db    = manage.Db
	)
	db.Find(&zones)
	db.Find(&ptrs)
	manage.updatePtrZone(zones, ADD)
	manage.updatePtr(ptrs, ADD)
	return nil
}
