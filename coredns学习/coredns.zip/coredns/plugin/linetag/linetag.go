package linetag

import (
	"context"
	"encoding/hex"
	"strings"

	"github.com/coredns/coredns/plugin"
	clog "github.com/coredns/coredns/plugin/pkg/log"
	"github.com/coredns/coredns/request"

	"github.com/miekg/dns"
)

var log = clog.NewWithPlugin(pluginName)

const pluginName = "linetag"

type LineTag struct {
	Next plugin.Handler
}

// ServeDNS implements the plugin.Handler interface.
func (tag LineTag) ServeDNS(ctx context.Context, w dns.ResponseWriter, r *dns.Msg) (int, error) {
	o := r.IsEdns0()
	if o != nil {
		r.Extra = nil
	}
	return plugin.NextOrFailure(pluginName, tag.Next, ctx, w, r)
}

// Metadata implements the metadata.Provider Interface in the metadata plugin, and is used to store
// the data associated with the source IP of every request.
func (tag LineTag) Metadata(ctx context.Context, state request.Request) context.Context {
	o := state.Req.IsEdns0()
	if o == nil {
		return ctx
	}

	for _, s := range o.Option {
		if e, ok := s.(*dns.EDNS0_COOKIE); ok {
			h, _ := hex.DecodeString(e.Cookie)
			ctx = context.WithValue(ctx, "geoip/lineIds", strings.Split(string(h), ","))
			log.Debugf("lineid is : %v", strings.Split(string(h), ","))
		}
	}
	return ctx
}

// Name implements the Handler interface.
func (tag LineTag) Name() string { return pluginName }
